# wallpaper-one
Recreation of my first ever computer on Wallpaper

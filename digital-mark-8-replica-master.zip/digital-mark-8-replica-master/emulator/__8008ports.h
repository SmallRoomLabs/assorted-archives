#ifndef READPORT00
#define READPORT00() {}
#endif
#ifndef READPORT01
#define READPORT01() {}
#endif
#ifndef READPORT02
#define READPORT02() {}
#endif
#ifndef READPORT03
#define READPORT03() {}
#endif
#ifndef READPORT04
#define READPORT04() {}
#endif
#ifndef READPORT05
#define READPORT05() {}
#endif
#ifndef READPORT06
#define READPORT06() {}
#endif
#ifndef READPORT07
#define READPORT07() {}
#endif
#ifndef WRITEPORT08
#define WRITEPORT08() {}
#endif
#ifndef WRITEPORT09
#define WRITEPORT09() {}
#endif
#ifndef WRITEPORT0A
#define WRITEPORT0A() {}
#endif
#ifndef WRITEPORT0B
#define WRITEPORT0B() {}
#endif
#ifndef WRITEPORT0C
#define WRITEPORT0C() {}
#endif
#ifndef WRITEPORT0D
#define WRITEPORT0D() {}
#endif
#ifndef WRITEPORT0E
#define WRITEPORT0E() {}
#endif
#ifndef WRITEPORT0F
#define WRITEPORT0F() {}
#endif
#ifndef WRITEPORT10
#define WRITEPORT10() {}
#endif
#ifndef WRITEPORT11
#define WRITEPORT11() {}
#endif
#ifndef WRITEPORT12
#define WRITEPORT12() {}
#endif
#ifndef WRITEPORT13
#define WRITEPORT13() {}
#endif
#ifndef WRITEPORT14
#define WRITEPORT14() {}
#endif
#ifndef WRITEPORT15
#define WRITEPORT15() {}
#endif
#ifndef WRITEPORT16
#define WRITEPORT16() {}
#endif
#ifndef WRITEPORT17
#define WRITEPORT17() {}
#endif
#ifndef WRITEPORT18
#define WRITEPORT18() {}
#endif
#ifndef WRITEPORT19
#define WRITEPORT19() {}
#endif
#ifndef WRITEPORT1A
#define WRITEPORT1A() {}
#endif
#ifndef WRITEPORT1B
#define WRITEPORT1B() {}
#endif
#ifndef WRITEPORT1C
#define WRITEPORT1C() {}
#endif
#ifndef WRITEPORT1D
#define WRITEPORT1D() {}
#endif
#ifndef WRITEPORT1E
#define WRITEPORT1E() {}
#endif
#ifndef WRITEPORT1F
#define WRITEPORT1F() {}
#endif

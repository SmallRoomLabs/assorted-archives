# digital-mark-8-replica
Mark 8 replica with Digital extensions (ASCII keyboard, 32 x 8 TVT)

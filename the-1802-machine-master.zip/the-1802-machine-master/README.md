# the-1802-machine
Home design of an RCA1802 based computer

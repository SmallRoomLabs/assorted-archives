#
#	Font text file parser.
#	
import re

characters = {}
currentCharacter = -1
currentText = ""

for l in [x.strip().replace("\t"," ") for x in open("font.txt").readlines()]:
	m = re.match("^([0-9]+)\s*(.*)$",l)
	if m is not None:
		currentCharacter = int(m.group(1))
		assert currentCharacter not in characters
		characters[currentCharacter] = []
		currentText = m.group(2)

	m = re.match("^([\.A-Z]+)$",l)
	if m is not None:
		s = (l+"....")[:4].replace(".","0").replace("X","1")
		if currentText != ".":
			s = s.replace(currentText,"1")
		characters[currentCharacter].append(int(s,2)*16)

for i in range(0,64):
	assert i in characters
	characters[i].append(0)
	print(i,characters[i])
	assert len(characters[i]) == 8


// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.c
//		Purpose:	Hardware handling routines (Mark 8/Hogenson specific)
//		Created:	1st January 2016
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include "sys_processor.h"

static BYTE8 keyboardPort;														// Keyboard port value exc. bit 7
static BYTE8 pendingKeyPress;													// Any key press that happened this frame
static BYTE8 isInitialised = 0;
static BYTE8 displayRAM[512];													// 64 lines of 8 bytes/64 pixels per line
static BYTE8 framesSinceEnabled = 0;											// Number of frames since display last enabled
static BYTE8 displayIsRunning = 0;												// True when display is running (e.g. visible)
static BYTE8 xCursor,yCursor; 													// Hogenson current counters.

// ST7920 SPI GLCD 128x64 Wiring.
//
// 	VSS,PSB,BLK 	GND	(PSB is mode select, low = SPI)
//	VDD,BLA 		5V
//	RS 				A0 (5V)
//	R/W 			A1 (MOSI)
//	E 				A2 (SCLK)
//
#ifdef ARDUINO
#include <Arduino.h>
#include <PS2Keyboard.h>
#include "ST7920LCDDriver.h"

#define ST7920_RW  			(A1)												// Connections to ST7920
#define ST7920_E  			(A2)
#define ST7920_RS  			(A0)

#define PS2KBD_DATA 		(2)													// Connections to PS/2 Keyboard Adaptor
#define PS2KBD_CLOCK 		(3)													

#define DIRTY_VIDEO() 	{ dirtyLine[yCursor] = 1;isDisplayDirty = 1; }			// Mark as dirty.
static BYTE8 dirtyLine[64];														// Each line marked as dirty, updated on frame end
static BYTE8 screenNeedsRepaint = 0;											// Flagged when any needs repainting

static ST7920LCDDriver lcd(ST7920_E, ST7920_RW, 0);
static PS2Keyboard keyboard;
#endif

// *******************************************************************************************************************************
//													Reset all hardware
// *******************************************************************************************************************************

void HWIReset(void) {
	keyboardPort = 0;															// Initialise states
	pendingKeyPress = 0;
	if (isInitialised == 0) {
		#ifdef ARDUINO
		keyboard.begin(PS2KBD_DATA,PS2KBD_CLOCK);								// Set up PS2 keyboard i/f
		isInitialised = 1;
		pinMode(ST7920_RS, OUTPUT); 											// Set up GLCD
	  	digitalWrite(ST7920_RS, HIGH);
	  	lcd.begin(true);          
	  	lcd.clear();
		#endif
	}
}

// *******************************************************************************************************************************
//													Read the keyboard port
// *******************************************************************************************************************************

BYTE8 HWIReadKeyboardPort(void) {
	BYTE8 rv = 0;
	if (keyboardPort != 0) {
		rv = keyboardPort | 0x80;
		keyboardPort = 0;
	}
	return rv;
}

// *******************************************************************************************************************************
//													Handle on end of frame.
// *******************************************************************************************************************************

void HWIEndFrame(void) {

	#ifdef ARDUINO
	if (screenNeedsRepaint != 0) {												// If any line needs repainting
		screenNeedsRepaint = 0;													// Clear flag
		for (BYTE8 y = 0;y < 64;y++) {											// Check each line
			if (dirtyLine[y] != 0) {											// If it is dirty ?
				dirtyLine[y] = 0;												// Clear that flag
				lcd.draw(0,y,displayRAM+y*8,8);									// Update the display.
			}
		}
	}
	if (keyboard.available()) {													// PS2 keyboard char ?
		pendingKeyPress = keyboard.read();										// Save it
		if (pendingKeyPress == PS2_BACKSPACE) pendingKeyPress = 8;				// Convert Backspace to CHR(8)
	}
	#endif

	if (displayIsRunning) {														// Track time display is on.
		framesSinceEnabled = 0;													// Display is on.
	} else {																	// Display is off.
		if (++framesSinceEnabled == 200) framesSinceEnabled = 200;				// Bump frames since enabled, limit to 200 (4s)
	}
	keyboardPort = pendingKeyPress & 0x7F; 										// Save any new key
	if (keyboardPort != 0) CPURequestInterrupt();								// Fire int on any new key
	pendingKeyPress = 0;														// Clear the key press buffer
}

#ifdef WINDOWS

// *******************************************************************************************************************************
//									Windows Keyboard Handler (links to Emulator Framework)
// *******************************************************************************************************************************

#include <gfx.h>

int HWIKeyboardHandler(int key,int runMode) {
	if (key != 0 && runMode != 0) {
		pendingKeyPress = GFXToASCII(key,1) & 0x7F;
	}
	return key;
}

#endif

// *******************************************************************************************************************************
//														Access video memory
// *******************************************************************************************************************************

BYTE8 *HWIGetVideoMemory(void) {
	if (framesSinceEnabled > FRAME_RATE/10) return NULL;					// Fade out after 1/10s.
	return displayRAM;
}

// *******************************************************************************************************************************
//													Set and clear pixel routines
// *******************************************************************************************************************************

#ifndef DIRTY_VIDEO															// Define dirty video if not already defined
#define DIRTY_VIDEO() {}													// as nothing.
#endif

void _HWISetPixel(void) {
	BYTE8 bit = (0x80 >> (xCursor & 7));									// bit mask.
	WORD16 addr = (xCursor >> 3) + yCursor * 8;								// address in video RAM.
	if ((displayRAM[addr] & bit) == 0) {									// only update if clear.
		displayRAM[addr] |= bit;											// set bit.
		DIRTY_VIDEO();														// mark position as dirty.
	}
}

void _HWIClearPixel(void) {
	BYTE8 bit = (0x80 >> (xCursor & 7));									// bit mask.
	WORD16 addr = (xCursor >> 3) + yCursor * 8;								// address in video RAM.
	if ((displayRAM[addr] & bit) != 0) {									// only update if set.
		displayRAM[addr] &= (bit ^ 0xFF);									// clear bit.
		DIRTY_VIDEO();														// mark position as dirty.
	}
}

// *******************************************************************************************************************************
//															Write to display
// *******************************************************************************************************************************

#include <stdio.h>

void HWIWriteDisplay(BYTE8 display) {
	if (displayIsRunning != 0) {											// Display is running. Only interested in TSF
		if ((display & 0307) == 0201) displayIsRunning = 0;					// TSF:2x1 because that turns the scan off.
	} else {																// Display is accessible.
		switch(display >> 6) {
			case 0:															// STX:0xx set x cursor
				xCursor = display & 0x3F;
				break;
			case 1:															// STY:1xx set y cursor
				yCursor = display & 0x3F;
				break;
			case 2:															// 2xc commands
				switch(display & 0307) {
					case 0200:												// 2x0:DCY decrement Y
						yCursor = (yCursor - 1) & 0x3F;
						break;
					case 0202:												// 2x2:ZON set Z on
						_HWISetPixel();
						break;
					case 0203:												// 2x3:ZOF set Z off
						_HWIClearPixel();
						break;
					case 0204:												// 2x4:ZNI set Z on and increment X
						_HWISetPixel();
						xCursor = (xCursor + 1) & 0x3F;
						if (xCursor == 0) yCursor = (yCursor + 1) & 0x3F;
						break;
					case 0205:												// 2x5:ZFI set Z off and increment X
						_HWIClearPixel();
						xCursor = (xCursor + 1) & 0x3F;
						if (xCursor == 0) yCursor = (yCursor + 1) & 0x3F;
						break;
					case 0206:												// 2x6:TSN turn scan on
						displayIsRunning = 1;
						break;
					case 0207:												// 2x7:DCX decrement X
						if (xCursor == 0) yCursor = (yCursor - 1) & 0x3F;
						xCursor = (xCursor - 1) & 0x3F;
						break;
				}
				break;
		}
	}
}
# digital-mark8-replica
Replica, Code, Emulation of Mark 8 with Digital Group Video, Keyboard, Cassette etc.

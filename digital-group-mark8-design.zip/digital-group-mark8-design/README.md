# digital-group-mark8-design
Software, Hardware and Emulation for the Mark 8 with the Suding Extensions as per Digital Group Packet #1

#elf-replica

Elf built around an Arduino, an SSD1306 OLED and a keypad.

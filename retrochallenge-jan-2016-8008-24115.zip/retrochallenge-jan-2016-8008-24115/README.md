# retrochallenge-jan-2016
My 8008 based Retrochallenge January 2016

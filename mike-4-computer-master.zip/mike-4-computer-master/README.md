# mike-4-computer
8008 based machine based on Mike 4 design, with Scopewriter

/*** Generated Code, do not edit ***/

#ifdef NEWMNEMONICS
static const char *_mnemonics[] = { "err %d","sha %d","and #%d","xor #%d","lda #%d","lca #%d","add #%d","sub #%d","and %d","and @%d","and %f","and %b","xor %d","xor @%d","xor %f","xor %b","lda %d","lda @%d","lda %f","lda %b","lca %d","lca @%d","lca %f","lca %b","add %d","add @%d","add %f","add %b","sub %d","sub @%d","sub %f","sub %b","sta %d","sta @%d","sta %f","sta %b","rml %d","rml @%d","rml %f","rml %b","adm %d","adm @%d","adm %f","adm %b","ild %d","ild @%d","ild %f","ild %b","jz %f","jnz %f","jpl %f","jmi %f","jz %b","jnz %b","jpl %b","jmi %b","jmp @%d","jmp @%f","inp %f","out %f","otc #%d","exf %f","ina","hlt %d"};
#else
static const char *_mnemonics[] = { "err","sha","lpn","lsn","ldn","lcn","adn","sbn","lpd","lpi","lpf","lpb","lsd","lsi","lsf","lsb","ldd","ldi","ldf","ldb","lcd","lci","lcf","lcb","add","adi","adf","adb","sbd","sbi","sbf","sbb","std","sti","stf","stb","srd","sri","srf","srb","rad","rai","raf","rab","aod","aoi","aof","aob","zjf","nzf","pjf","njf","zjb","nzb","pjb","njb","jpi","jfi","inp","out","otn","exf","ina","hlt"};
#endif

#
#	Compile 3 x 7 font.
#
import re

font = [ None ] * 128
current = -1

src = [x.strip().upper() for x in open("font.txt").readlines() if x.strip() != ""]
src = [x for x in src if x[0] != '#']
for l in src:
	#print(l)
	m = re.match("^\:\(([0-9]+)\).*$",l)
	if m is not None:
		n = int(m.group(1))
		assert n >= 0  and n < 128
		current = n
		assert font[current] is None
		font[current] = []
	else:
		m = re.match("^[\.X][\.X][\.X]$",l)
		assert m is not None
		l = l.replace(".","0").replace("X","1")
		font[current].append(int(l,2) << 5)

for i in range(0,128):
	assert font[i] is not None
	assert len(font[i]) == 7
	font[i].append(0)

flat = [item for sublist in font for item in sublist]
assert len(flat) == 128 * 8

open("__font3x7_mcmfont.h","w").write(",".join([str(x) for x in flat]))
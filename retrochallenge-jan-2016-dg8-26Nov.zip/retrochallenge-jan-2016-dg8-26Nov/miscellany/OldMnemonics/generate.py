#
#		Generate old Mnemonics, list from http://petsd.net/8008.php
#
def define(mn,opcode):
	assert mnemonic[opcode] == "   "
	mnemonic[opcode] = mn.upper()
#
#		Encode up to 3 character word into 15 bits.
#
def encode(s):
	s = (s+"   ")[:3].upper()
	r = 0
	for i in range(0,3):
		c = s[i]
		assert (c >= 'A' and c <= 'Z') or c == ' '
		if c != ' ':
			r = (r << 5) | (ord(c) - 64)
	return r

#
#	Add standard 8008 old mnemonics.
#
mnemonic = [ "   " ] * 256

define("hlt",0)
define("hlt",1)
define("hlt",255)

for port in range(0,8):
	define("ip"+chr(port+97),0x41+port*2)
	define("op"+chr(port+97),0x51+port*2)

for n in range(0,8):
	define("jmp",0x44+n*8)
	cond = "ft"[n >> 2] + "czsp"[n % 4]
	define("j"+cond,0x40+n*8)
	define("cal",0x46+n*8)
	define("c"+cond,0x42+n*8)
	define("ret",0x07+n*8)
	define("r"+cond,0x03+n*8)
	define("rs"+chr(n+97),0x05+n*8)

reg = [x for x in "abcdehlm"]

for d in range(0,8):
	for s in range(0,8):
		if d != 7 or s != 7:
			define("l"+reg[d]+reg[s],0xC0+d*8+s)

	define("l"+reg[d]+"i",0x06+d*8)
	if d != 0 and d != 7:
		define("in"+reg[d],0x00+d*8)
		define("dc"+reg[d],0x01+d*8)

	for alu in range(0,8):
		op = [ "ad","ac","su","sb","nd","xr","or","cp" ][alu]
		if d == 0:
			define(op+"i",0x04+alu * 8)
		define(op+reg[d],0x80+alu*8+d)

define("rlc",0x02)
define("rrc",0x0A)
define("ral",0x12)
define("rar",0x1A)

#
#	Check immediate and jump test algorithm.
#
immediateList = []
jumpList = []
for i in range(0,256):
	if (i & 0xC5) == 0x04:
		assert(mnemonic[i][-1] == 'I')
		immediateList.append(mnemonic[i])
	if (i & 0xC1) == 0x40:
		assert (mnemonic[i][0] == 'J' or mnemonic[i][0] == 'C') and mnemonic[:2] != "CP"
		jumpList.append(mnemonic[i])

assert len(immediateList) == 16				# 8 ALU immediates, 8 register immediates
assert len(jumpList) == 32 					# 8 Jump, 8 Call, 8 Jump Cond, 8 Call Cond

codes = [encode(x) for x in mnemonic]		# create 15 bit mnemonics table.

#
#	Add commands.
#
commandList = []

commandList.append("l") 					# L [nnnn] hex list from nnnn or current position.
commandList.append("d") 					# D [nnnn] disassemble from nnnn
commandList.append("r")						# R 	   display registers
commandList.append("a")						# A [nnnn] set/display current address
commandList.append("d")						# D nn 	   store data at current address and bump.
commandList.append("run") 					# RUN [nnnn] execute from current address
commandList.append("s") 					# B [nnnn] set breakpoint at current address
commandList.append("get") 					# GET [nnnn] input tape to current address
commandList.append("put")					# PUT nnnn   output tape from current address, nnnn bytes.

for cmd in commandList:						# do each command
	op = [n for n in range(0,256) if codes[n] == 0][0] 	# find an empty slot.
	mnemonic[op] = "*"+cmd.upper()			# set the mnemonic with a marker.
	codes[op] = encode(cmd)|0x8000 			# set the code with bit 15 set.

#print(immediateList)
#print(jumpList)
#print(mnemonic)
#print(codes)

h = open("__mnemonics.asm","w")
h.write(";\n; 	Mnemonic to opcode table\n;\n")
for i in range(0,256):
	h.write("    dw {0:5}   ; {1}\n".format(codes[i],mnemonic[i].replace("*","Command:")))

h = open("__commands.inc","w")
h.write(";\n; 	Monitor commands\n;\n")
for i in range(0,256):
	if (codes[i] & 0x8000) != 0:
		h.write("{0:12} = {1}\n".format("MonCmd_"+mnemonic[i][1:],i))
# retrochallenge-jan-2016
My 8008 based Retrochallenge Jan 2016 project, done early :)


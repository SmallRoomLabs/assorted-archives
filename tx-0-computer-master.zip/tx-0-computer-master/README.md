# tx-0-computer
Emulator, Code, Hardware for Tx-0 computer

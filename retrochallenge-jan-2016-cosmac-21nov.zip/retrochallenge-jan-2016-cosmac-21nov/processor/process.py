import re

def process(s,opcode):
	s = s.replace("@P",str(opcode % 8))
	s = s.replace("@EF",str(opcode % 4 + 1))
	s = s.replace("@X","{0:X}".format(opcode % 16))

	return s

lines = [x.replace("\t"," ").rstrip() for x in open("rca1802.def").readlines()]
lines = [x if x.find("//") < 0 else x[:x.find("//")].rstrip() for x in lines]
lines = [x for x in lines if x != ""]
open("__1802support.h","w").write("\n".join([x[1:] for x in lines if x[0] == ':']))
lines = [x for x in lines if x[0] != ':']

mnemonics = [ None ] * 256
code = [ None ] * 256

lines = "\n".join(lines).replace("\n ",";").split("\n")
for l in lines:
	m = re.match("^([0-9A-Fa-f\-]+)\s*\"([A-Z\s\@\%1268]+)\"\s*(.*)$",l)
	assert m is not None
	r = m.group(1)+"-"+m.group(1)
	for opcode in range(int(r[:2],16),int(r[3:5],16)+1):
		assert mnemonics[opcode] is None
		mnemonics[opcode] = process(m.group(2).strip(),opcode).lower()
		code[opcode] = process(m.group(3).strip(),opcode)

open("__1802mnemonics.h","w").write(",".join('"'+x+'"' for x in mnemonics))

handle = open("__1802opcodes.h","w")
for n in range(0,256):
	handle.write("case 0x{0:02x}: /***** {1} *****/\n".format(n,mnemonics[n]))
	c = code[n]+";break;".replace(";;",";")
	c = ["    "+x+";" for x in c.split(";") if x != ""]
	handle.write("\n".join(c));
	handle.write("\n");

handle = open("__1802ports.h","w")
for n in range(1,8):
	handle.write("#ifndef INPORT{0}\n#define INPORT{0}() (0)\n#endif\n".format(n))
	handle.write("#ifndef OUTPORT{0}\n#define OUTPORT{0}(n) {{}}\n#endif\n".format(n))
handle.write("#ifndef UPDATEQ\n#define UPDATEQ(n) {{}}\n#endif\n")
for n in range(1,5):
	handle.write("#ifndef EFLAG{0}\n#define EFLAG{0}() (0)\n#endif\n".format(n))

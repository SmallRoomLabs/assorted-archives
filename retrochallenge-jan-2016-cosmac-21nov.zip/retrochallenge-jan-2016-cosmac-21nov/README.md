# retrochallenge-jan-2016
Cosmac VIP 1802 based Retrochallenge Jan 2016

// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.cpp
//		Purpose:	Hardware Interface - bridge between the drivers and the processor.
//		Created:	1st January 2016
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include <stdlib.h>
#include "sys_processor.h"
#include "hardware.h"
#include "drivers.h"
#ifdef WINDOWS
#include "gfx.h"
#endif

static WORD16 videoMemoryAddress = 0xFFFF;										// 1802 Video Memory Address
static BYTE8  screenIsOn = 0;													// 1861 turned on
static BYTE8  *videoMemoryPointer = NULL;										// Physical screen memory ptr in SRAM
static BYTE8  videoDisplay[512];												// Maintained display cache (up to 64x64 resolution)
																				// we do not support 64x128 display.

static BYTE8  transientKeyPending;												// Any key pressed this frame ?
static BYTE8  transientKeyState;												// State of the transient key.
static BYTE8  keyboardLatch; 													// Keyboard input latch (Elf 74922)
static BYTE8  currentKeyboardLatchKey; 											// Current state of keyboard latch press

// *******************************************************************************************************************************
//													Hardware Reset
// *******************************************************************************************************************************

void HWIReset(void) {
	screenIsOn = 0;
	videoMemoryPointer = NULL;
	transientKeyState = 0;
	transientKeyPending = 0;
	for (WORD16 n = 0;n < 512;n++) videoDisplay[n] = 0;
}

// *******************************************************************************************************************************
//							Get/Set the page address (1802 and Physical) for the video.
// *******************************************************************************************************************************

void HWISetPageAddress(WORD16 r0,BYTE8 *pointer) {
	videoMemoryAddress = r0;
	videoMemoryPointer = pointer;
}

// *******************************************************************************************************************************
//											Return shadow of video display
// *******************************************************************************************************************************

BYTE8 *HWIGetVideoMemoryAddress(void) {
	return videoDisplay;
}

// *******************************************************************************************************************************
//											Get/Set the screen on flag
// *******************************************************************************************************************************

BYTE8 HWISetScreenOn(BYTE8 isOn) {
	screenIsOn = (isOn != 0);
	return screenIsOn;
}

BYTE8 HWIGetScreenOn(void) {
	return screenIsOn;
}

// *******************************************************************************************************************************
//													Read the keyboard latch
// *******************************************************************************************************************************

BYTE8 HWIGetKeyboardLatch(void) {
	return keyboardLatch;
}

// *******************************************************************************************************************************
//												Get current key pressed, if any.
// *******************************************************************************************************************************

BYTE8 HWIGetASCIIKeyboard(void) {
	return transientKeyState;
}

// *******************************************************************************************************************************
//													Is IN pressed ?
// *******************************************************************************************************************************

BYTE8 HWIIsINPressed(void) {
	return DRVIsINPressed();
}

// *******************************************************************************************************************************
//												Called at End of Frame
// *******************************************************************************************************************************

#include <stdio.h>

void HWIEndFrame(BYTE8 driverLines) {
	if (screenIsOn && videoMemoryPointer != NULL) {								// Tell the driver which bytes of screen memory have changed
		for (WORD16 n = 0;n < driverLines*8;n++) {								// Scan memory.
			if (videoDisplay[n] != videoMemoryPointer[n]) {						// Changed from cached version
				videoDisplay[n] = videoMemoryPointer[n];						// Update cache
				// TODO: Call driver write
				// TODO: Function to copy video display for different writings
			}
		}
	}
	DRVUpdateKeyboard();														// Check for any keys pressed.
	transientKeyState = transientKeyPending;									// If key pressed, pretend it is held for one frame.
	transientKeyPending = 0;

	BYTE8 newLatch = 0xFF;														// Which if any of the hex keys is
	for (BYTE8 n = 0;n < 16;n++) 												// pressed.
		if (HWIIsHexKeyPressed(n)) newLatch = n;
	if (newLatch != 0xFF && newLatch != currentKeyboardLatchKey) {				// One of them pressed ??
		keyboardLatch = (keyboardLatch << 4) | newLatch; 						// Shift into keyboard latch.
	}
	currentKeyboardLatchKey = newLatch;											// Remember state.
}

// *******************************************************************************************************************************
//								Check to see if hex key is pressed, including ASCII keyboard usage
// *******************************************************************************************************************************

BYTE8 HWIIsHexKeyPressed(BYTE8 hexDigit) {
	BYTE8 isPressed = DRVIsHexKeyPressed(hexDigit);								// Driver first
	if (isPressed == 0 && transientKeyState != 0) {								// If fail, check for keyboard press
		BYTE8 uKey = transientKeyState;											// Get key
		if (uKey >= 'a' && uKey <= 'z') uKey -= 32;								// Capitalise it
		if ("0123456789ABCDEF"[hexDigit] == uKey) isPressed = 1;				// If its the hex key required it's pressed.
	}
	return isPressed;
}

// *******************************************************************************************************************************
//									"Clean" video memory - used by drivers for chunk updating
// *******************************************************************************************************************************

void HWICleanVideoMemory(WORD16 offset) {
	videoDisplay[offset] = videoMemoryPointer[offset];
}

// *******************************************************************************************************************************
//												 Handle Transient Keys
// *******************************************************************************************************************************

void HWIProcessKeyboardEvent(BYTE8 key) {
	key = key & 0x7F;															// Only interested in bits 0..6
	if (key != 0) transientKeyPending = key;									// If a key, mark it as pending.
}

// *******************************************************************************************************************************
//							Windows has a built in keyboard handler via Framework
// *******************************************************************************************************************************

#ifdef WINDOWS
BYTE8 HWIProcessKey(BYTE8 key,BYTE8 isRunMode) {
	if (key != 0 && isRunMode != 0) {
		HWIProcessKeyboardEvent(GFXToASCII(key,1));
	}
	return key;
}

// *******************************************************************************************************************************
//												Hex keypad support
// *******************************************************************************************************************************

BYTE8 DRVIsHexKeyPressed(BYTE8 hexValue) {
	return GFXIsKeyPressed("0123456789ABCDEF"[hexValue]);
}

// *******************************************************************************************************************************
//												IN for Elf device
// *******************************************************************************************************************************

BYTE8 DRVIsINPressed(void) {
	return GFXIsKeyPressed(GFXKEY_RETURN);
}

// *******************************************************************************************************************************
//											Dummy keyboard check routine
// *******************************************************************************************************************************

void DRVUpdateKeyboard(void) {
}

#endif

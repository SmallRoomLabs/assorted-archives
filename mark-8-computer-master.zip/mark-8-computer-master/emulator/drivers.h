// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		drivers.h
//		Purpose:	Target dependent code (header)
//		Created:	2nd October
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#ifndef _DRIVERS_H
#define _DRIVERS_H

BYTE8 DRVGetKeyIfAvailable(void);
int DRVProcessDebugKey(int key,int isRunMode);
void DRVInitialise(void);
void DRVEndFrame(void);
void DRVSetPixel(BYTE8 x,BYTE8 y,BYTE8 isOn);

#endif
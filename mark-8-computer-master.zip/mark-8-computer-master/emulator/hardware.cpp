// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.c
//		Purpose:	Hardware handling routines (Mark-8/Hogenson specific)
//					Interface between the processor core and the external drivers.
//		Created:	2nd October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include "sys_processor.h"
#include "drivers.h"

static BYTE8 	currentKey = 0x00; 													// Current pressed key.

static BYTE8 	xDisplay,yDisplay; 													// Display coordinates.
static BYTE8 	isScannerOn; 														// Non-zero if scanner is on.
static WORD16 	framesSinceLastChange; 												// Frames since last display on/off change

// *******************************************************************************************************************************
//													Reset all hardware
// *******************************************************************************************************************************

void HWIReset(void) {
	DRVInitialise();																// Initialise the driver
}

// *******************************************************************************************************************************
//														Read keyboard
// *******************************************************************************************************************************

BYTE8 HWIReadKeyboard(void) {
	return currentKey;
}

// *******************************************************************************************************************************
//						Write to display (Note: this is the extended version in "Best of Byte vol 1")
// *******************************************************************************************************************************

#include <stdio.h>

void HWIWriteDisplay(BYTE8 command) {

	if (isScannerOn != 0) { 														// If scanner on.
		if ((command & 0307) != 0201) return;										// Ignore all commands except 2x1
	}																				// which turns it off.

	switch(command >> 6) {
		case 0:		xDisplay = command;												// 0xx set x position.
					break;
		case 1:		yDisplay = command & 0x3F;										// 1xx set y position
					break;
		case 2:		switch(command & 7) {											// 2?c command
						case 0:	yDisplay--;break; 									// 200 decrement Y
						case 1: isScannerOn = 0;framesSinceLastChange = 0;break;	// 201 scan off
						case 2:	DRVSetPixel(xDisplay,yDisplay,1);break;				// 202 set pixel
						case 3:	DRVSetPixel(xDisplay,yDisplay,0);break;				// 203 clear pixel
						case 4:	DRVSetPixel(xDisplay,yDisplay,1);xDisplay++;break;	// 204 set pixel increment X
						case 5:	DRVSetPixel(xDisplay,yDisplay,0);xDisplay++;break;	// 205 clear pixel increment X
						case 6: isScannerOn = 1;framesSinceLastChange = 0;break;	// 206 scan on
						case 7: xDisplay--;break;									// 207 decrement X
					}
					if (xDisplay >= 0x40) yDisplay++; 								// Off right move down.
					xDisplay &= 0x3F;yDisplay &= 0x3F; 								// Make counters 6 bit.
					break;
	}
}

// *******************************************************************************************************************************
//													Handle on end of frame.
// *******************************************************************************************************************************

void HWIEndFrame(void) {
	BYTE8 newKey = DRVGetKeyIfAvailable();											// New key press ?
	if (newKey != 0) {																// If so, update current key
		currentKey = newKey;
		CPURequestInterrupt();														// and ask for an interrupt.
	}
	framesSinceLastChange++; 														// Bump change counter.
	DRVEndFrame();
}


# mark-8-computer
Emulation/Recreation of Mark 8 Computer with ASCII keyboard and "Hogenson" 64 x 64 pixel display

// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.cpp
//		Purpose:	Hardware handling routines
//		Created:	1st January 2016
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include "sys_processor.h"

static BYTE8 keyboardPort;														// Keyboard port value exc. bit 7
static BYTE8 pendingKeyPress;													// Any key press that happened this frame
static BYTE8 isInitialised = 0;													// Has hardware been initialised ?

// ST7920 SPI GLCD 128x64 Wiring.
//
// 	VSS,PSB,BLK 	GND	(PSB is mode select, low = SPI)
//	VDD,BLA 		5V
//	RS 				A0 (5V)
//	R/W 			A1 (MOSI)
//	E 				A2 (SCLK)
//
#ifdef ARDUINO
#include <Arduino.h>
#include <PS2Keyboard.h>
#include "ST7920LCDDriver.h"

#define ST7920_RW  			(A1)												// Connections to ST7920
#define ST7920_E  			(A2)
#define ST7920_RS  			(A0)

#define PS2KBD_DATA 		(2)													// Connections to PS/2 Keyboard Adaptor
#define PS2KBD_CLOCK 		(3)													

#define PIEZO_BUZZER		(12) 												// Piezo Buzzer

static ST7920LCDDriver lcd(ST7920_E, ST7920_RW, 0);								// LCD object
static PS2Keyboard keyboard;													// Keyboard object
static BYTE8 screenNeedsRepaint;												// Repaint flag.

#endif

#ifdef WINDOWS
#include "gfx.h"
#endif

// *******************************************************************************************************************************
//													Reset all hardware
// *******************************************************************************************************************************

void HWIReset(void) {
	keyboardPort = 0;															// Initialise states
	pendingKeyPress = 0;
	if (isInitialised == 0) {
		#ifdef ARDUINO
		keyboard.begin(PS2KBD_DATA,PS2KBD_CLOCK);								// Set up PS2 keyboard i/f
		isInitialised = 1;
		pinMode(ST7920_RS, OUTPUT); 											// Set up GLCD
	  	digitalWrite(ST7920_RS, HIGH);
	  	lcd.begin(true);          
	  	lcd.clear();
		#endif
	}
}

// *******************************************************************************************************************************
//													Read the keyboard port
// *******************************************************************************************************************************

BYTE8 HWIReadKeyboardPort(void) {
	BYTE8 rv = 0;
	if (keyboardPort != 0) {
		rv = keyboardPort;
		keyboardPort = 0;
	}
	return rv;
}

// *******************************************************************************************************************************
//													Handle on end of frame.
// *******************************************************************************************************************************

void HWIEndFrame(void) {

	#ifdef ARDUINO
	if (screenNeedsRepaint != 0) {												// If any line needs repainting
		screenNeedsRepaint = 0;													// Clear flag
	}
	if (keyboard.available()) {													// PS2 keyboard char ?
		pendingKeyPress = keyboard.read();										// Save it
		if (pendingKeyPress == PS2_BACKSPACE) pendingKeyPress = 8;				// Convert Backspace to CHR(8)
	}
	#endif
	if (pendingKeyPress != 0 && keyboardPort == 0) CPUWakeProcessor();			// Recover from HALT on key press.
	keyboardPort = pendingKeyPress & 0x7F; 										// Save any new key
	pendingKeyPress = 0;														// Clear the key press buffer
}

#ifdef WINDOWS

// *******************************************************************************************************************************
//									Windows Keyboard Handler (links to Emulator Framework)
// *******************************************************************************************************************************

#include <gfx.h>

int HWIKeyboardHandler(int key,int runMode) {
	if (key != 0 && runMode != 0) {
		pendingKeyPress = GFXToASCII(key,1) & 0x7F;
	}
	return key;
}

#endif

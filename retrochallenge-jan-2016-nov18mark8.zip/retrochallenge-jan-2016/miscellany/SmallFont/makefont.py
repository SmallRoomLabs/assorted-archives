#
#	Font text file parser.
#	
import re

def checkReduce(pattern,match):
	for i in range(0,7):
		#print("{0:06x}".format(pattern))
		pattern = pattern >> 3
		#print("   {0:06x}".format(pattern))
		test = ((pattern >> 6) | (pattern >> 3) | pattern) & 0xFF
		#print("{3}:{0:06x} {1:06x} {2}".format(pattern,test,match,i))
		if i == 6:
			assert test == match
		else:
			assert test != match

characters = {}
currentCharacter = -1
currentText = ""
fontData = [ ] 

for l in [x.strip().replace("\t"," ") for x in open("font.txt").readlines()]:
	m = re.match("^([0-9]+)\s*(.*)$",l)
	if m is not None:
		currentCharacter = int(m.group(1))
		assert currentCharacter not in characters
		characters[currentCharacter] = []
		currentText = m.group(2) if currentCharacter != 32 else " "

	m = re.match("^([\.A-Z]+)$",l)
	if m is not None:
		s = (l.strip()+"...")[:3].replace(".","0").replace("X","1")
		if currentText != "." and currentText != " ":
			s = s.replace(currentText,"1")
		characters[currentCharacter].append(int(s,2))

for i in range(0,64):
	assert i in characters
	assert len(characters[i]) == 7
	pattern = 0
	for j in range(0,7):
		pattern = (pattern << 3) + characters[i][j]
	pattern = pattern | 0xE00000
	print("{0} {1} {2:06x}".format(i,characters[i],pattern))
	checkReduce(pattern,0x7)
	fd = "{0:06x}".format(pattern)
	fontData.append(fd[:2])
	fontData.append(fd[2:4])
	fontData.append(fd[4:])

open("__fontdata.h","w").write(",".join(["0x"+x for x in fontData]))

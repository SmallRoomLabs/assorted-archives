for i in range(32,96):
	print('{0} "{1:c}"'.format(i & 63,i))
	print("")
	for j in range(0,5):
		print("XXXXX")
	print("")

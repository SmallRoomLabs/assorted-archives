// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.cpp
//		Purpose:	Hardware Interface - bridge between the drivers and the processor.
//		Created:	1st January 2016
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include <stdlib.h>
#include "sys_processor.h"
#include "hardware.h"
#ifdef WINDOWS
#include "gfx.h"
#endif

static WORD16 videoMemoryAddress = 0xFFFF;										// 1802 Video Memory Address
static BYTE8  screenIsOn = 0;													// 1861 turned on
static BYTE8  *videoMemoryPointer = NULL;										// Physical screen memory ptr in SRAM
static BYTE8  videoDisplay[512];												// Maintained display cache (up to 64x64 resolution)
																				// we do not support 64x128 display.

static BYTE8  transientKeyPending;												// Any key pressed this frame ?
static BYTE8  transientKeyState;												// State of the transient key.

// *******************************************************************************************************************************
//													Hardware Reset
// *******************************************************************************************************************************

void HWIReset(void) {
	screenIsOn = 0;
	videoMemoryPointer = NULL;
	transientKeyState = 0;
	transientKeyPending = 0;
	for (WORD16 n = 0;n < 512;n++) videoDisplay[n] = 0;
}

// *******************************************************************************************************************************
//							Get/Set the page address (1802 and Physical) for the video.
// *******************************************************************************************************************************

void HWISetPageAddress(WORD16 r0,BYTE8 *pointer) {
	videoMemoryAddress = r0;
	videoMemoryPointer = pointer;
}

// *******************************************************************************************************************************
//											Return shadow of video display
// *******************************************************************************************************************************

BYTE8 *HWIGetVideoMemoryAddress(void) {
	return videoDisplay;
}

// *******************************************************************************************************************************
//											Get/Set the screen on flag
// *******************************************************************************************************************************

BYTE8 HWISetScreenOn(BYTE8 isOn) {
	screenIsOn = (isOn != 0);
	return screenIsOn;
}

BYTE8 HWIGetScreenOn(void) {
	return screenIsOn;
}

// *******************************************************************************************************************************
//												Called at End of Frame
// *******************************************************************************************************************************

#include <stdio.h>

void HWIEndFrame(BYTE8 driverLines) {
	if (screenIsOn && videoMemoryPointer != NULL) {								// Tell the driver which bytes of screen memory have changed
		for (WORD16 n = 0;n < driverLines*8;n++) {								// Scan memory.
			if (videoDisplay[n] != videoMemoryPointer[n]) {						// Changed from cached version
				videoDisplay[n] = videoMemoryPointer[n];						// Update cache
				// TODO: Call driver write
				// TODO: Function to copy video display for different writings
			}
		}
	}
	transientKeyState = transientKeyPending;									// If key pressed, pretend it is held for one frame.
	transientKeyPending = 0;
}

// *******************************************************************************************************************************
//												 Handle Transient Keys
// *******************************************************************************************************************************

void HWIProcessKeyboardEvent(BYTE8 key) {
	key = key & 0x7F;															// Only interested in bits 0..6
	if (key != 0) transientKeyPending = key;									// If a key, mark it as pending.
}

// *******************************************************************************************************************************
//							Windows has a built in keyboard handler via Framework
// *******************************************************************************************************************************

#ifdef WINDOWS
BYTE8 HWIProcessKey(BYTE8 key,BYTE8 isRunMode) {
	if (key != 0 && isRunMode != 0) {
		transientKeyPending = GFXToASCII(key,1);
	}
	return key;
}
#endif
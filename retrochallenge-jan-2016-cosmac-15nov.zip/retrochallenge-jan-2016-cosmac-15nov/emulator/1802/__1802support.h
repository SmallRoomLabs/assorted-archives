static BYTE8  D,DF,IE,Q,T,P,X;
static WORD16  R0,R1,R2,R3,R4,R5,R6,R7,R8,R9,RA,RB,RC,RD,RE,RF;
static BYTE8   MB,temp8;
static WORD16  MA,temp16,cycles;
static WORD16 *rPtr[16] = { &R0,&R1,&R2,&R3,&R4,&R5,&R6,&R7,&R8,&R9,&RA,&RB,&RC,&RD,&RE,&RF };
static void __RCA1802_Reset(void) {
 Q = 0;UPDATEQ(Q);IE = 1;
 X = 0;P = 0;R0 = 0;
}
#define INDEXREGISTER (*rPtr[X])
#define RCA1802_ADD()  { temp16 = D + MB + DF; D = temp16; DF = temp16 >> 8; }
#define RCA1802_SUBD() { temp16 = MB - D - DF;D = temp16; DF = (temp16 >> 8) & 1; }
#define RCA1802_SUBM() { temp16 = D - MB - DF;D = temp16; DF = (temp16 >> 8) & 1; }
#define BRANCH()  *rPtr[P] = ((*rPtr[P]) & 0xFF00) | MB
#define LONGBRANCH()  *rPtr[P] = temp16
#define LONGFETCH()  { FETCH();temp16 = MB << 8;FETCH();temp16 |= MB; }
static void __RCA1802_Interrupt(void) {
 if (IE != 0) {
  T = (X << 4) | P;
  P = 1;
  X = 2;
  IE = 0;
 }
}
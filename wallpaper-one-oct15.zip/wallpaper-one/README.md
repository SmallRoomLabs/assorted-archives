# wallpaper-one
Recreation of my first ever computer, designed on wallpaper

# the-8008-machine
My 8008 based design for 8008 software development

# martin-mike-4-computer
Martin Research's Mike 4 design, tweaked, with a Scopewriter interface

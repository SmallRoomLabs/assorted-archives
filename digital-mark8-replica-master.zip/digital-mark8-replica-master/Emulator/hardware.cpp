// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.c
//		Purpose:	Hardware handling routines (Scelbi specific)
//		Created:	1st September 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include "sys_processor.h"
#include "interface.h"

static BYTE8 	lastVideoPort = 0x00;												// Last value written to video.
static BYTE8    vduCounter = 0x00;													// Value on the 74193 counters
static BYTE8 	keyboardPort = 0x00;		

// *******************************************************************************************************************************
//												Byte read from the I/O ports
// *******************************************************************************************************************************

BYTE8 	HWIReadPort(BYTE8 portID,BYTE8 acc) { 
	BYTE8 retVal = 0;
	switch(portID) {
		case 0x00:																	// In 0 reads keyboard port.
			retVal = keyboardPort;break;
	}
	return retVal; 
}

// *******************************************************************************************************************************
//												Byte written to the I/O ports
// *******************************************************************************************************************************

void HWIWritePort(BYTE8 portID,BYTE8 data) {
	switch(portID) {
		case 0x0E:																	// Called "Out 6" actually Out 0xE
			if ((lastVideoPort & 0x80) != (data & 0x80)) {							// Value changed.
				lastVideoPort = data; 												// Update last video write
				if ((data & 0x80) != 0) {											// Bit 7 high this time.
					if (data == 0xFF) { 											// $FF 'homes' the write position.
						vduCounter = 0;
					} else {														// Otherwise write it out.
						IFWriteVideo(vduCounter,data & 0x7F);
						vduCounter = (vduCounter + 1) & 0xFF;
					}
				}
			}
			break;
	}

}

// *******************************************************************************************************************************
//													Handle on end of frame.
// *******************************************************************************************************************************

void HWIEndFrame(void) {
	keyboardPort = IFReadKeyboard();												// Very long strobe time of 1 frame.
	if (keyboardPort != 0) keyboardPort |= 0x80;									// Set here, cleared next time.
}


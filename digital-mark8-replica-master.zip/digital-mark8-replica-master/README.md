# digital-mark8-replica
Mark 8 with Digital Group Hardware (32 x 8 Video, ASCII Keyboard)

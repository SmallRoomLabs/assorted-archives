// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.c
//		Purpose:	Hardware handling routines (Scrumpi 3 specific)
//		Created:	1st January 2016
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#ifdef WINDOWS
#include <stdio.h>
#include "gfx.h"
#endif

#ifdef ARDUINO
#include <Arduino.h>
#include <PS2Keyboard.h>
#include "ST7920LCDDriver.h"
#endif

#include "sys_processor.h"

static BYTE8 needsRepaint = 0;														// Non-zero when needs repainting.
static BYTE8 pendingKey = 0;														// Key ready ?
static BYTE8 dirtyQuads[64];														// ST7920 operates in 4 char chunks.
static BYTE8 currentKey;															// Current key pressed.

#ifdef ARDUINO
#define SPI_MOSI   		A1
#define SPI_CLK   		A2
#define SPI_ENABLE     	A0 
static ST7920LCDDriver lcd(SPI_CLK, SPI_MOSI, 0);

#define DATA_PIN 		(2)															// Connection to PS2 keyboard
#define CLOCK_PIN 		(3)													
static PS2Keyboard keyboard;														// Keyboard object

#endif


// *******************************************************************************************************************************
//													Reset all hardware
// *******************************************************************************************************************************

void HWIReset(void) {
#ifdef ARDUINO
	pinMode(SPI_ENABLE, OUTPUT);   
  	digitalWrite(SPI_ENABLE, HIGH);
  	lcd.begin(true);          
  	lcd.clear();
	keyboard.begin(DATA_PIN,CLOCK_PIN);												// Set up PS2 keyboard
#endif
}

// *******************************************************************************************************************************
//											Mark a VRAM address as being changed
// *******************************************************************************************************************************

void HWIMarkVideoDirty(BYTE8 address) {
	needsRepaint = 1;
	dirtyQuads[address >> 2] = 1;													// ST7920 operates in chunks of 4.
}

// *******************************************************************************************************************************
//													Handle on end of frame.
// *******************************************************************************************************************************

void HWIEndFrame(void) {
#ifdef ARDUINO
	if (needsRepaint) {																// Needs repainting.
		needsRepaint = 0;															// Clear flag
		for (BYTE8 n = 0;n < 64;n++) {
			if (dirtyQuads[n] != 0) {
				dirtyQuads[n] = 0;
				lcd.drawText(n % 8,n/8*8,CPUGetVideoMemory()+n*4);
			}
		}
	}
	if (keyboard.available()) {														// Key available ?
		pendingKey = keyboard.read();												// Read it.
		if (pendingKey >= 0x80) pendingKey = 0;										// Remove high characters
		if (pendingKey == PS2_BACKSPACE) pendingKey = 8;							// Backspace returns chr(8)
	}
#endif
	currentKey = pendingKey;
	pendingKey = 0;																	// Comment out to run test code kbd.
}

// *******************************************************************************************************************************
//									Debugger key intercept handler
// *******************************************************************************************************************************

#ifdef WINDOWS
int HWIProcessKey(int key,int isRunTime) {
	if (key != 0 && isRunTime != 0) {												// Running and key press
		BYTE8 newKey = GFXToASCII(key,1);											// Convert to ASCII
		if (newKey != 0) pendingKey = newKey;										// Put pending key in buffer
	}
	return key;
}
#endif

// *******************************************************************************************************************************
//											Read keyboard
// *******************************************************************************************************************************

BYTE8 HWIReadKeyboard(void) {
	return currentKey;
}

// *******************************************************************************************************************************
//						Convert ASCII to keypad byte, reading on column provided.
//	This code is based on row = address read, lower 4 bits
//		Bit 3	:	checking 12-15
//		Bit 2	:	checking 8-11
//		Bit 1	: 	checking 4-7
//		Bit 0	: 	checking 0-3
//
//	The read data is : DB7 Extra DB6 Punc DB5 Alpha2 DB4 Alpha1 DB3 Col 0 DB1 Col 1 DB2 Col 2 DB3 Col 3, so, 
//	as an example 'A' sets DB4 (Alpha 1) and DB1 when row bit 0 is checked (e.g. reading $C01). e.g. 00010100
//	0001000 is read when Bit 0 of the address is low. All inputs are active '1'.
// *******************************************************************************************************************************

BYTE8 HWIConvertASCIIToScrumpi(BYTE8 kbd,BYTE8 rowBits) {
	if (currentKey == 0x08) return 0x80;											// Backspace is the extra key (DB7)
	BYTE8 key = currentKey;															// Get the current key.
	if (key >= 'a' && key <= 'z') key = key - 32;									// Convert to upper case.
	if (key < 32 || key >= 96) return 0;											// Not supported by keyboard.

	BYTE8 rv = 0;
	if (key < 48) rv |= 0x40;														// Punc is DB6
	if (key >= 80) rv |= 0x20;														// Alpha 2 is DB5
	if (key >= 64 && key < 80) rv |= 0x10;											// Alpha 1 is DB4
	key = key & 0x0F;																// Only interested in lower 4 bits.

	for (BYTE8 row = 0;row < 4;row++) {												// For each row
		if ((rowBits & (0x08 >> row)) != 0) {										// Is the row bit flag set ?
			if ((3 - row) == key / 4) {												// In same row as key ?
				rv = rv | (0x08 >> (key % 4));										// Set the output bit.
			}
		}
	}
	return rv;
}

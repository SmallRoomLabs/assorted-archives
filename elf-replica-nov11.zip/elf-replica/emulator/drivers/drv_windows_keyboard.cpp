// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		drv_windows_keyboard.cpp
//		Purpose:	Windows keyboard driver.
//		Created:	30th October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include "drivers.h"
#include "gfx.h"

// *******************************************************************************************************************************
//											Process keys passed from debugger
// *******************************************************************************************************************************

BYTE8 HWIProcessKey(BYTE8 key,BYTE8 isRunMode) {
	if (isRunMode) {															// In run mode, push 0-9 A-F
		BYTE8 akey = GFXToASCII(key,1);											// Convert key to ASCII.
		if (akey != 0) HWIProcessKeyboardEvent(akey);							// Pass it to the transient keyboard driver (for ASCII)
	}
	return key;
}

void DRVUpdateKeyboard(void) {} 							

// *******************************************************************************************************************************
//								We can access the keypad and IN directly using the framework
// *******************************************************************************************************************************

BYTE8 DRVGetKeypadState(BYTE8 keyID) {
	if (keyID == DRV_KEYPAD_IN) return GFXIsKeyPressed(GFXKEY_RETURN);			// Handle In.
	return GFXIsKeyPressed("0123456789ABCDEF"[keyID & 0xFF]);
}

// *******************************************************************************************************************************
//					We let the Transition Handler handle keyboard presses though, hence return 0 here.
// *******************************************************************************************************************************

BYTE8 DRVGetASCIIKeyboardState(void) {
	return 0;
}


// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		hardware.cpp
//		Purpose:	Hardware Interface - bridge between the drivers and the processor.
//		Created:	29th October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include <stdlib.h>
#include "sys_processor.h"
#include "hardware.h"
#include "drivers.h"

static WORD16 videoMemoryAddress = 0xFFFF;										// 1802 Video Memory Address
static BYTE8  screenIsOn = 0;													// 1861 turned on
static BYTE8  keypadLatch = 0;													// 74922 keyboard latch (Elf)
static BYTE8  ledDisplay = 0;													// 8 LED / 2 Digit display (Elf)
static BYTE8  *videoMemoryPointer = NULL;										// Physical screen memory ptr in SRAM
static BYTE8  videoDisplay[512];												// Maintained display cache (up to 64x64 resolution)
																				// we do not support 64x128 display.

static BYTE8  hexKeypadState; 													// Hex keypad press state, for Elf keypad.

static BYTE8  transientKeyPending;												// Any key pressed this frame ?
static BYTE8  transientKeyState;												// State of the transient key.

// *******************************************************************************************************************************
//													Hardware Reset
// *******************************************************************************************************************************

void HWIReset(void) {
	screenIsOn = 0;
	ledDisplay = 0;
	videoMemoryPointer = NULL;
	transientKeyState = 0;
	transientKeyPending = 0;
	hexKeypadState = 0;
	for (WORD16 n = 0;n < 512;n++) videoDisplay[n] = 0;
	DRVUpdateKeyboard();
}

// *******************************************************************************************************************************
//									Get/Set the 7 Segment Display And/Or LEDs
// *******************************************************************************************************************************

void HWISetDigitDisplay(BYTE8 led) {
	ledDisplay = led;
}

BYTE8 HWIGetDigitDisplay(void) {
	return ledDisplay;
}

// *******************************************************************************************************************************
//							Get/Set the page address (1802 and Physical) for the video.
// *******************************************************************************************************************************

void HWISetPageAddress(WORD16 r0,BYTE8 *pointer) {
	videoMemoryAddress = r0;
	videoMemoryPointer = pointer;
}

// *******************************************************************************************************************************
//											Return shadow of video display
// *******************************************************************************************************************************

BYTE8 *HWIGetVideoMemoryAddress(void) {
	return videoDisplay;
}

// *******************************************************************************************************************************
//											Get/Set the screen on flag
// *******************************************************************************************************************************

void HWISetScreenOn(BYTE8 isOn) {
	screenIsOn = (isOn != 0);
}

BYTE8 HWIGetScreenOn(void) {
	return screenIsOn;
}

// *******************************************************************************************************************************
//											  Check if IN is pressed
// *******************************************************************************************************************************

BYTE8 HWIIsInPressed(void) {
	if (DRVGetKeypadState(DRV_KEYPAD_IN) != 0) return -1;
	if (transientKeyState == 13) return -1;
	return 0;
}

// *******************************************************************************************************************************
//											Read the 749C22 Keyboard Latch
// *******************************************************************************************************************************

BYTE8 HWIReadKeypadLatch(void) {
	return keypadLatch;
}

// *******************************************************************************************************************************
//											 Update the Elf Keypad Latch
// *******************************************************************************************************************************

static void _HWIUpdateKeypadLatch(void) {
	BYTE8 currentKey = 0xFF;													// Nothing pressed
	for (BYTE8 n = 0;n < 16;n++) {												// Check all the keys to see if one is pressed.
		if (DRVGetKeypadState(n) != 0) currentKey = n;							// If so, mark that current.
	}
	if (currentKey == 0xFF && transientKeyState != 0) {							// Nothing pressed, and a transient key ?
		BYTE8 k = transientKeyState;											// Get key state
		if (k >= '0' && k <= '9') currentKey = k - '0';							// Update current key if Hex key
		if (k >= 'A' && k <= 'F') currentKey = k - 'A' + 10;
		if (k >= 'a' && k <= 'f') currentKey = k - 'a' + 10;		
	}
	if (currentKey != hexKeypadState && currentKey != 0xFF) {					// Change of key and a key is pressed.
		keypadLatch = (keypadLatch << 4) | currentKey;							// Update the latch
	}
	hexKeypadState = currentKey;												// Remember current state
}

// *******************************************************************************************************************************
//												Called at End of Frame
// *******************************************************************************************************************************

#include <stdio.h>

void HWIEndFrame(BYTE8 driverLines) {
	if (screenIsOn && videoMemoryPointer != NULL) {								// Tell the driver which bytes of screen memory have changed
		for (WORD16 n = 0;n < driverLines*8;n++) {								// Scan memory.
			if (videoDisplay[n] != videoMemoryPointer[n]) {						// Changed from cached version
				videoDisplay[n] = videoMemoryPointer[n];						// Update cache
				DRVWriteDisplay(n,videoDisplay[n]);								// Call driver.
			}
		}
	}
	_HWIUpdateKeypadLatch();													// Update the keypad latch, if used.
	DRVUpdateKeyboard();														// Update the keyboard.
	transientKeyState = transientKeyPending;									// If key pressed, pretend it is held for one frame.
	transientKeyPending = 0;
}

// *******************************************************************************************************************************
//												 Handle Transient Keys
// *******************************************************************************************************************************

void HWIProcessKeyboardEvent(BYTE8 key) {
	key = key & 0x7F;															// Only interested in bits 0..6
	if (key != 0) transientKeyPending = key;									// If a key, mark it as pending.
}


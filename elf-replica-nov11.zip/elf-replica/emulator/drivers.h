// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		drivers.h
//		Purpose:	Drivers (Header)
//		Created:	30th October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#ifndef _DRIVERS_H
#define _DRIVERS_H
#include "sys_processor.h"

BYTE8 DRVGetASCIIKeyboardState(void);
BYTE8 DRVGetKeypadState(BYTE8 key);
void DRVUpdateKeyboard(void);

#define DRV_KEYPAD_IN	(0xFF)

void DRVWriteDisplay(BYTE8 offset,BYTE8 data);
void DRVUpdateDisplay(void);

void HWIProcessKeyboardEvent(BYTE8 key);
#endif
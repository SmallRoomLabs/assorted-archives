#elf-replica

Elf replica, easy build.

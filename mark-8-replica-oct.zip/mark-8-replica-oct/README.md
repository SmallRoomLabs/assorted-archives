# mark-8-replica
Mark 8 Replica with ASCII Keyboard and Hogenson Scope Display, no Blinkenlights

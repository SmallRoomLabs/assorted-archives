// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		main.cpp
//		Purpose:	Simple hardware test for Keyboard, LCD and Buzzer.
//		Created:	30th October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include <Arduino.h>
#include <LiquidCrystal.h>
#include <PS2Keyboard.h>

#define PS2KBD_DATA  	2											// Data pin from PS/2 Adaptor
#define PS2KBD_CLOCK   	3											// Clock pin from PS/2 Adaptor
#define BUZZER_PIN 		13 											// Piezo Buzzer (if we use this....)

#define LCD_RS			9 											// LCD Connecting pins (4 bit)
#define LCD_E 			8
#define LCD_D4 			7
#define LCD_D5			6
#define LCD_D6			5
#define LCD_D7 			4

static PS2Keyboard keyboard;
static LiquidCrystal lcd(LCD_RS,LCD_E,LCD_D4,LCD_D5,LCD_D6,LCD_D7);	// LCD Pins RS,E,D4,D5,D6,D7

void setup() {
	keyboard.begin(PS2KBD_DATA,PS2KBD_CLOCK);						// Initialise keyboard
  	lcd.begin(16, 2);												// Initialise LCD
  	lcd.print("Mike 4 H/W Test");									// Message on top line.
}

void loop() {
	if (keyboard.available()) {										// Key pressed ?
		int n = keyboard.read();									// Read it
		lcd.setCursor(0,1);											// Draw on second line
		lcd.print(n);
		lcd.print("   ");
		tone(BUZZER_PIN,n*5+200,500);								// Slightly related beep
	}
}

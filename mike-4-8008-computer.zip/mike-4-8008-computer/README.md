# mike-4-8008-computer
Hardware, Emulator, Software for Martin Research "Mike 4" design and PE Scopewriter

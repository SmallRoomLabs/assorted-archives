// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		drivers.h
//		Purpose:	Driver function headers
//		Created:	1st January 2016
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************


void  DRVUpdateKeyboard(void);														// Keyboard update.

BYTE8 DRVIsHexKeyPressed(BYTE8 hexValue);											// Test if hex keypad key pressed
																					// (if not using ASCII keyboard)

BYTE8 DRVIsINPressed(void);															// IN key pressed (ELF only)
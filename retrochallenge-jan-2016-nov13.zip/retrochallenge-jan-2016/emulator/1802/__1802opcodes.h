case 0x00: /***** idl *****/
    break;
case 0x01: /***** ldn r1 *****/
    MA = R1;
    READ();
    D = MB;
    break;
case 0x02: /***** ldn r2 *****/
    MA = R2;
    READ();
    D = MB;
    break;
case 0x03: /***** ldn r3 *****/
    MA = R3;
    READ();
    D = MB;
    break;
case 0x04: /***** ldn r4 *****/
    MA = R4;
    READ();
    D = MB;
    break;
case 0x05: /***** ldn r5 *****/
    MA = R5;
    READ();
    D = MB;
    break;
case 0x06: /***** ldn r6 *****/
    MA = R6;
    READ();
    D = MB;
    break;
case 0x07: /***** ldn r7 *****/
    MA = R7;
    READ();
    D = MB;
    break;
case 0x08: /***** ldn r8 *****/
    MA = R8;
    READ();
    D = MB;
    break;
case 0x09: /***** ldn r9 *****/
    MA = R9;
    READ();
    D = MB;
    break;
case 0x0a: /***** ldn ra *****/
    MA = RA;
    READ();
    D = MB;
    break;
case 0x0b: /***** ldn rb *****/
    MA = RB;
    READ();
    D = MB;
    break;
case 0x0c: /***** ldn rc *****/
    MA = RC;
    READ();
    D = MB;
    break;
case 0x0d: /***** ldn rd *****/
    MA = RD;
    READ();
    D = MB;
    break;
case 0x0e: /***** ldn re *****/
    MA = RE;
    READ();
    D = MB;
    break;
case 0x0f: /***** ldn rf *****/
    MA = RF;
    READ();
    D = MB;
    break;
case 0x10: /***** inc r0 *****/
    R0++;
    break;
case 0x11: /***** inc r1 *****/
    R1++;
    break;
case 0x12: /***** inc r2 *****/
    R2++;
    break;
case 0x13: /***** inc r3 *****/
    R3++;
    break;
case 0x14: /***** inc r4 *****/
    R4++;
    break;
case 0x15: /***** inc r5 *****/
    R5++;
    break;
case 0x16: /***** inc r6 *****/
    R6++;
    break;
case 0x17: /***** inc r7 *****/
    R7++;
    break;
case 0x18: /***** inc r8 *****/
    R8++;
    break;
case 0x19: /***** inc r9 *****/
    R9++;
    break;
case 0x1a: /***** inc ra *****/
    RA++;
    break;
case 0x1b: /***** inc rb *****/
    RB++;
    break;
case 0x1c: /***** inc rc *****/
    RC++;
    break;
case 0x1d: /***** inc rd *****/
    RD++;
    break;
case 0x1e: /***** inc re *****/
    RE++;
    break;
case 0x1f: /***** inc rf *****/
    RF++;
    break;
case 0x20: /***** dec r0 *****/
    R0--;
    break;
case 0x21: /***** dec r1 *****/
    R1--;
    break;
case 0x22: /***** dec r2 *****/
    R2--;
    break;
case 0x23: /***** dec r3 *****/
    R3--;
    break;
case 0x24: /***** dec r4 *****/
    R4--;
    break;
case 0x25: /***** dec r5 *****/
    R5--;
    break;
case 0x26: /***** dec r6 *****/
    R6--;
    break;
case 0x27: /***** dec r7 *****/
    R7--;
    break;
case 0x28: /***** dec r8 *****/
    R8--;
    break;
case 0x29: /***** dec r9 *****/
    R9--;
    break;
case 0x2a: /***** dec ra *****/
    RA--;
    break;
case 0x2b: /***** dec rb *****/
    RB--;
    break;
case 0x2c: /***** dec rc *****/
    RC--;
    break;
case 0x2d: /***** dec rd *****/
    RD--;
    break;
case 0x2e: /***** dec re *****/
    RE--;
    break;
case 0x2f: /***** dec rf *****/
    RF--;
    break;
case 0x30: /***** br %1 *****/
    FETCH();
    BRANCH();
    break;
case 0x31: /***** bq %1 *****/
    FETCH();
    if (Q != 0) BRANCH();
    break;
case 0x32: /***** bz %1 *****/
    FETCH();
    if (D == 0) BRANCH();
    break;
case 0x33: /***** bdf %1 *****/
    FETCH();
    if (DF != 0) BRANCH();
    break;
case 0x34: /***** b1 %1 *****/
    FETCH();
    if (EFLAG1() != 0) BRANCH();
    break;
case 0x35: /***** b2 %1 *****/
    FETCH();
    if (EFLAG2() != 0) BRANCH();
    break;
case 0x36: /***** b3 %1 *****/
    FETCH();
    if (EFLAG3() != 0) BRANCH();
    break;
case 0x37: /***** b4 %1 *****/
    FETCH();
    if (EFLAG4() != 0) BRANCH();
    break;
case 0x38: /***** skp *****/
    FETCH();
    break;
case 0x39: /***** bnq %1 *****/
    FETCH();
    if (Q == 0) BRANCH();
    break;
case 0x3a: /***** bnz %1 *****/
    FETCH();
    if (D != 0) BRANCH();
    break;
case 0x3b: /***** bnf %1 *****/
    FETCH();
    if (DF == 0) BRANCH();
    break;
case 0x3c: /***** bn1 %1 *****/
    FETCH();
    if (EFLAG1() == 0) BRANCH();
    break;
case 0x3d: /***** bn2 %1 *****/
    FETCH();
    if (EFLAG2() == 0) BRANCH();
    break;
case 0x3e: /***** bn3 %1 *****/
    FETCH();
    if (EFLAG3() == 0) BRANCH();
    break;
case 0x3f: /***** bn4 %1 *****/
    FETCH();
    if (EFLAG4() == 0) BRANCH();
    break;
case 0x40: /***** lda r0 *****/
    MA = R0;
    READ();
    D = MB;
    R0++;
    break;
case 0x41: /***** lda r1 *****/
    MA = R1;
    READ();
    D = MB;
    R1++;
    break;
case 0x42: /***** lda r2 *****/
    MA = R2;
    READ();
    D = MB;
    R2++;
    break;
case 0x43: /***** lda r3 *****/
    MA = R3;
    READ();
    D = MB;
    R3++;
    break;
case 0x44: /***** lda r4 *****/
    MA = R4;
    READ();
    D = MB;
    R4++;
    break;
case 0x45: /***** lda r5 *****/
    MA = R5;
    READ();
    D = MB;
    R5++;
    break;
case 0x46: /***** lda r6 *****/
    MA = R6;
    READ();
    D = MB;
    R6++;
    break;
case 0x47: /***** lda r7 *****/
    MA = R7;
    READ();
    D = MB;
    R7++;
    break;
case 0x48: /***** lda r8 *****/
    MA = R8;
    READ();
    D = MB;
    R8++;
    break;
case 0x49: /***** lda r9 *****/
    MA = R9;
    READ();
    D = MB;
    R9++;
    break;
case 0x4a: /***** lda ra *****/
    MA = RA;
    READ();
    D = MB;
    RA++;
    break;
case 0x4b: /***** lda rb *****/
    MA = RB;
    READ();
    D = MB;
    RB++;
    break;
case 0x4c: /***** lda rc *****/
    MA = RC;
    READ();
    D = MB;
    RC++;
    break;
case 0x4d: /***** lda rd *****/
    MA = RD;
    READ();
    D = MB;
    RD++;
    break;
case 0x4e: /***** lda re *****/
    MA = RE;
    READ();
    D = MB;
    RE++;
    break;
case 0x4f: /***** lda rf *****/
    MA = RF;
    READ();
    D = MB;
    RF++;
    break;
case 0x50: /***** str r0 *****/
    MA = R0;
    MB = D;
    WRITE();
    break;
case 0x51: /***** str r1 *****/
    MA = R1;
    MB = D;
    WRITE();
    break;
case 0x52: /***** str r2 *****/
    MA = R2;
    MB = D;
    WRITE();
    break;
case 0x53: /***** str r3 *****/
    MA = R3;
    MB = D;
    WRITE();
    break;
case 0x54: /***** str r4 *****/
    MA = R4;
    MB = D;
    WRITE();
    break;
case 0x55: /***** str r5 *****/
    MA = R5;
    MB = D;
    WRITE();
    break;
case 0x56: /***** str r6 *****/
    MA = R6;
    MB = D;
    WRITE();
    break;
case 0x57: /***** str r7 *****/
    MA = R7;
    MB = D;
    WRITE();
    break;
case 0x58: /***** str r8 *****/
    MA = R8;
    MB = D;
    WRITE();
    break;
case 0x59: /***** str r9 *****/
    MA = R9;
    MB = D;
    WRITE();
    break;
case 0x5a: /***** str ra *****/
    MA = RA;
    MB = D;
    WRITE();
    break;
case 0x5b: /***** str rb *****/
    MA = RB;
    MB = D;
    WRITE();
    break;
case 0x5c: /***** str rc *****/
    MA = RC;
    MB = D;
    WRITE();
    break;
case 0x5d: /***** str rd *****/
    MA = RD;
    MB = D;
    WRITE();
    break;
case 0x5e: /***** str re *****/
    MA = RE;
    MB = D;
    WRITE();
    break;
case 0x5f: /***** str rf *****/
    MA = RF;
    MB = D;
    WRITE();
    break;
case 0x60: /***** irx *****/
    (INDEXREGISTER)++;
    break;
case 0x61: /***** out 1 *****/
    MA = INDEXREGISTER;
    READ();
    OUTPORT1(MB);
    INDEXREGISTER++;
    break;
case 0x62: /***** out 2 *****/
    MA = INDEXREGISTER;
    READ();
    OUTPORT2(MB);
    INDEXREGISTER++;
    break;
case 0x63: /***** out 3 *****/
    MA = INDEXREGISTER;
    READ();
    OUTPORT3(MB);
    INDEXREGISTER++;
    break;
case 0x64: /***** out 4 *****/
    MA = INDEXREGISTER;
    READ();
    OUTPORT4(MB);
    INDEXREGISTER++;
    break;
case 0x65: /***** out 5 *****/
    MA = INDEXREGISTER;
    READ();
    OUTPORT5(MB);
    INDEXREGISTER++;
    break;
case 0x66: /***** out 6 *****/
    MA = INDEXREGISTER;
    READ();
    OUTPORT6(MB);
    INDEXREGISTER++;
    break;
case 0x67: /***** out 7 *****/
    MA = INDEXREGISTER;
    READ();
    OUTPORT7(MB);
    INDEXREGISTER++;
    break;
case 0x68: /***** nop68 *****/
    break;
case 0x69: /***** inp 1 *****/
    MB = INPORT1();
    D = MB;
    MA = INDEXREGISTER;
    WRITE();
    break;
case 0x6a: /***** inp 2 *****/
    MB = INPORT2();
    D = MB;
    MA = INDEXREGISTER;
    WRITE();
    break;
case 0x6b: /***** inp 3 *****/
    MB = INPORT3();
    D = MB;
    MA = INDEXREGISTER;
    WRITE();
    break;
case 0x6c: /***** inp 4 *****/
    MB = INPORT4();
    D = MB;
    MA = INDEXREGISTER;
    WRITE();
    break;
case 0x6d: /***** inp 5 *****/
    MB = INPORT5();
    D = MB;
    MA = INDEXREGISTER;
    WRITE();
    break;
case 0x6e: /***** inp 6 *****/
    MB = INPORT6();
    D = MB;
    MA = INDEXREGISTER;
    WRITE();
    break;
case 0x6f: /***** inp 7 *****/
    MB = INPORT7();
    D = MB;
    MA = INDEXREGISTER;
    WRITE();
    break;
case 0x70: /***** ret *****/
    MA = INDEXREGISTER;
    READ();
    INDEXREGISTER++;
    X = MB >> 4;
    P = MB & 0x0F;
    IE = 1;
    break;
case 0x71: /***** dis *****/
    MA = INDEXREGISTER;
    READ();
    INDEXREGISTER++;
    X = MB >> 4;
    P = MB & 0x0F;
    IE = 0;
    break;
case 0x72: /***** ldxa *****/
    MA = INDEXREGISTER;
    READ();
    D = MB;
    (INDEXREGISTER)++;
    break;
case 0x73: /***** stxd *****/
    MA = INDEXREGISTER;
    MB = D;
    WRITE();
    (INDEXREGISTER)--;
    break;
case 0x74: /***** adc *****/
    MA = INDEXREGISTER;
    READ();
    RCA1802_ADD();
    break;
case 0x75: /***** sdb *****/
    MA = INDEXREGISTER;
    READ();
    RCA1802_SUBD();
    break;
case 0x76: /***** rshr *****/
    temp8 = D & 1;
    D = (D >> 1) | (DF << 7);
    DF = temp8;
    break;
case 0x77: /***** smb *****/
    MA = INDEXREGISTER;
    READ();
    RCA1802_SUBM();
    break;
case 0x78: /***** sav *****/
    MA = INDEXREGISTER;
    MB = T;
    WRITE();
    break;
case 0x79: /***** mark *****/
    T = (X << 4) | P;
    MA = R2;
    MB = (X << 4) | P;
    WRITE();
    X = P;
    R2--;
    break;
case 0x7a: /***** req *****/
    if (Q != 0) { Q = 0;
    UPDATEQ(0);
     };
    break;
case 0x7b: /***** seq *****/
    if (Q == 0) { Q = 1;
    UPDATEQ(1);
     };
    break;
case 0x7c: /***** adci %1 *****/
    FETCH();
    RCA1802_ADD();
    break;
case 0x7d: /***** sdbi %1 *****/
    FETCH();
    RCA1802_SUBD();
    break;
case 0x7e: /***** rshl *****/
    temp8 = D >> 7;
    D = (D << 1) | DF;
    DF = temp8;
    break;
case 0x7f: /***** smbi %1 *****/
    FETCH();
    RCA1802_SUBM();
    break;
case 0x80: /***** glo r0 *****/
    D = R0;
    break;
case 0x81: /***** glo r1 *****/
    D = R1;
    break;
case 0x82: /***** glo r2 *****/
    D = R2;
    break;
case 0x83: /***** glo r3 *****/
    D = R3;
    break;
case 0x84: /***** glo r4 *****/
    D = R4;
    break;
case 0x85: /***** glo r5 *****/
    D = R5;
    break;
case 0x86: /***** glo r6 *****/
    D = R6;
    break;
case 0x87: /***** glo r7 *****/
    D = R7;
    break;
case 0x88: /***** glo r8 *****/
    D = R8;
    break;
case 0x89: /***** glo r9 *****/
    D = R9;
    break;
case 0x8a: /***** glo ra *****/
    D = RA;
    break;
case 0x8b: /***** glo rb *****/
    D = RB;
    break;
case 0x8c: /***** glo rc *****/
    D = RC;
    break;
case 0x8d: /***** glo rd *****/
    D = RD;
    break;
case 0x8e: /***** glo re *****/
    D = RE;
    break;
case 0x8f: /***** glo rf *****/
    D = RF;
    break;
case 0x90: /***** ghi r0 *****/
    D = R0 >> 8;
    break;
case 0x91: /***** ghi r1 *****/
    D = R1 >> 8;
    break;
case 0x92: /***** ghi r2 *****/
    D = R2 >> 8;
    break;
case 0x93: /***** ghi r3 *****/
    D = R3 >> 8;
    break;
case 0x94: /***** ghi r4 *****/
    D = R4 >> 8;
    break;
case 0x95: /***** ghi r5 *****/
    D = R5 >> 8;
    break;
case 0x96: /***** ghi r6 *****/
    D = R6 >> 8;
    break;
case 0x97: /***** ghi r7 *****/
    D = R7 >> 8;
    break;
case 0x98: /***** ghi r8 *****/
    D = R8 >> 8;
    break;
case 0x99: /***** ghi r9 *****/
    D = R9 >> 8;
    break;
case 0x9a: /***** ghi ra *****/
    D = RA >> 8;
    break;
case 0x9b: /***** ghi rb *****/
    D = RB >> 8;
    break;
case 0x9c: /***** ghi rc *****/
    D = RC >> 8;
    break;
case 0x9d: /***** ghi rd *****/
    D = RD >> 8;
    break;
case 0x9e: /***** ghi re *****/
    D = RE >> 8;
    break;
case 0x9f: /***** ghi rf *****/
    D = RF >> 8;
    break;
case 0xa0: /***** plo r0 *****/
    R0 = (R0 & 0xFF00) | D;
    break;
case 0xa1: /***** plo r1 *****/
    R1 = (R1 & 0xFF00) | D;
    break;
case 0xa2: /***** plo r2 *****/
    R2 = (R2 & 0xFF00) | D;
    break;
case 0xa3: /***** plo r3 *****/
    R3 = (R3 & 0xFF00) | D;
    break;
case 0xa4: /***** plo r4 *****/
    R4 = (R4 & 0xFF00) | D;
    break;
case 0xa5: /***** plo r5 *****/
    R5 = (R5 & 0xFF00) | D;
    break;
case 0xa6: /***** plo r6 *****/
    R6 = (R6 & 0xFF00) | D;
    break;
case 0xa7: /***** plo r7 *****/
    R7 = (R7 & 0xFF00) | D;
    break;
case 0xa8: /***** plo r8 *****/
    R8 = (R8 & 0xFF00) | D;
    break;
case 0xa9: /***** plo r9 *****/
    R9 = (R9 & 0xFF00) | D;
    break;
case 0xaa: /***** plo ra *****/
    RA = (RA & 0xFF00) | D;
    break;
case 0xab: /***** plo rb *****/
    RB = (RB & 0xFF00) | D;
    break;
case 0xac: /***** plo rc *****/
    RC = (RC & 0xFF00) | D;
    break;
case 0xad: /***** plo rd *****/
    RD = (RD & 0xFF00) | D;
    break;
case 0xae: /***** plo re *****/
    RE = (RE & 0xFF00) | D;
    break;
case 0xaf: /***** plo rf *****/
    RF = (RF & 0xFF00) | D;
    break;
case 0xb0: /***** phi r0 *****/
    R0 = (R0 & 0x00FF) | (D << 8);
    break;
case 0xb1: /***** phi r1 *****/
    R1 = (R1 & 0x00FF) | (D << 8);
    break;
case 0xb2: /***** phi r2 *****/
    R2 = (R2 & 0x00FF) | (D << 8);
    break;
case 0xb3: /***** phi r3 *****/
    R3 = (R3 & 0x00FF) | (D << 8);
    break;
case 0xb4: /***** phi r4 *****/
    R4 = (R4 & 0x00FF) | (D << 8);
    break;
case 0xb5: /***** phi r5 *****/
    R5 = (R5 & 0x00FF) | (D << 8);
    break;
case 0xb6: /***** phi r6 *****/
    R6 = (R6 & 0x00FF) | (D << 8);
    break;
case 0xb7: /***** phi r7 *****/
    R7 = (R7 & 0x00FF) | (D << 8);
    break;
case 0xb8: /***** phi r8 *****/
    R8 = (R8 & 0x00FF) | (D << 8);
    break;
case 0xb9: /***** phi r9 *****/
    R9 = (R9 & 0x00FF) | (D << 8);
    break;
case 0xba: /***** phi ra *****/
    RA = (RA & 0x00FF) | (D << 8);
    break;
case 0xbb: /***** phi rb *****/
    RB = (RB & 0x00FF) | (D << 8);
    break;
case 0xbc: /***** phi rc *****/
    RC = (RC & 0x00FF) | (D << 8);
    break;
case 0xbd: /***** phi rd *****/
    RD = (RD & 0x00FF) | (D << 8);
    break;
case 0xbe: /***** phi re *****/
    RE = (RE & 0x00FF) | (D << 8);
    break;
case 0xbf: /***** phi rf *****/
    RF = (RF & 0x00FF) | (D << 8);
    break;
case 0xc0: /***** lbr %2 *****/
    LONGFETCH();
    LONGBRANCH();
    THREECYCLES;
    break;
case 0xc1: /***** lbq %2 *****/
    LONGFETCH();
    if (Q != 0) LONGBRANCH();
    THREECYCLES;
    break;
case 0xc2: /***** lbz %2 *****/
    LONGFETCH();
    if (D == 0) LONGBRANCH();
    THREECYCLES;
    break;
case 0xc3: /***** lbdf %2 *****/
    LONGFETCH();
    if (DF != 0) LONGBRANCH();
    THREECYCLES;
    break;
case 0xc4: /***** nop *****/
    THREECYCLES;
    break;
case 0xc5: /***** lsnq %1 *****/
    if (Q == 0) LONGFETCH();
    THREECYCLES;
    break;
case 0xc6: /***** lsnz %1 *****/
    if (D != 0) LONGFETCH();
    THREECYCLES;
    break;
case 0xc7: /***** lsnf %1 *****/
    if (DF == 0) LONGFETCH();
    THREECYCLES;
    break;
case 0xc8: /***** lskp *****/
    LONGFETCH();
    THREECYCLES;
    break;
case 0xc9: /***** lbnq %2 *****/
    LONGFETCH();
    if (Q == 0) LONGBRANCH();
    THREECYCLES;
    break;
case 0xca: /***** lbnz %2 *****/
    LONGFETCH();
    if (D != 0) LONGBRANCH();
    THREECYCLES;
    break;
case 0xcb: /***** lbnf %2 *****/
    LONGFETCH();
    if (DF == 0) LONGBRANCH();
    THREECYCLES;
    break;
case 0xcc: /***** lsie %1 *****/
    if (IE != 0) LONGFETCH();
    THREECYCLES;
    break;
case 0xcd: /***** lsq %1 *****/
    if (Q != 0) LONGFETCH();
    THREECYCLES;
    break;
case 0xce: /***** lsz %1 *****/
    if (D == 0) LONGFETCH();
    THREECYCLES;
    break;
case 0xcf: /***** lsdf %1 *****/
    if (DF != 0) LONGFETCH();
    THREECYCLES;
    break;
case 0xd0: /***** sep r0 *****/
    P = 0x0;
    break;
case 0xd1: /***** sep r1 *****/
    P = 0x1;
    break;
case 0xd2: /***** sep r2 *****/
    P = 0x2;
    break;
case 0xd3: /***** sep r3 *****/
    P = 0x3;
    break;
case 0xd4: /***** sep r4 *****/
    P = 0x4;
    break;
case 0xd5: /***** sep r5 *****/
    P = 0x5;
    break;
case 0xd6: /***** sep r6 *****/
    P = 0x6;
    break;
case 0xd7: /***** sep r7 *****/
    P = 0x7;
    break;
case 0xd8: /***** sep r8 *****/
    P = 0x8;
    break;
case 0xd9: /***** sep r9 *****/
    P = 0x9;
    break;
case 0xda: /***** sep ra *****/
    P = 0xA;
    break;
case 0xdb: /***** sep rb *****/
    P = 0xB;
    break;
case 0xdc: /***** sep rc *****/
    P = 0xC;
    break;
case 0xdd: /***** sep rd *****/
    P = 0xD;
    break;
case 0xde: /***** sep re *****/
    P = 0xE;
    break;
case 0xdf: /***** sep rf *****/
    P = 0xF;
    break;
case 0xe0: /***** sex r0 *****/
    X = 0x0;
    break;
case 0xe1: /***** sex r1 *****/
    X = 0x1;
    break;
case 0xe2: /***** sex r2 *****/
    X = 0x2;
    break;
case 0xe3: /***** sex r3 *****/
    X = 0x3;
    break;
case 0xe4: /***** sex r4 *****/
    X = 0x4;
    break;
case 0xe5: /***** sex r5 *****/
    X = 0x5;
    break;
case 0xe6: /***** sex r6 *****/
    X = 0x6;
    break;
case 0xe7: /***** sex r7 *****/
    X = 0x7;
    break;
case 0xe8: /***** sex r8 *****/
    X = 0x8;
    break;
case 0xe9: /***** sex r9 *****/
    X = 0x9;
    break;
case 0xea: /***** sex ra *****/
    X = 0xA;
    break;
case 0xeb: /***** sex rb *****/
    X = 0xB;
    break;
case 0xec: /***** sex rc *****/
    X = 0xC;
    break;
case 0xed: /***** sex rd *****/
    X = 0xD;
    break;
case 0xee: /***** sex re *****/
    X = 0xE;
    break;
case 0xef: /***** sex rf *****/
    X = 0xF;
    break;
case 0xf0: /***** ldx *****/
    MA = INDEXREGISTER;
    READ();
    D = MB;
    break;
case 0xf1: /***** or *****/
    MA = INDEXREGISTER;
    READ();
    D |= MB;
    break;
case 0xf2: /***** and *****/
    MA = INDEXREGISTER;
    READ();
    D &= MB;
    break;
case 0xf3: /***** xor *****/
    MA = INDEXREGISTER;
    READ();
    D ^= MB;
    break;
case 0xf4: /***** add *****/
    MA = INDEXREGISTER;
    READ();
    DF = 0;
    RCA1802_ADD();
    break;
case 0xf5: /***** sd *****/
    MA = INDEXREGISTER;
    READ();
    DF = 0;
    RCA1802_SUBD();
    break;
case 0xf6: /***** shr *****/
    DF = D & 1;
    D = D >> 1;
    break;
case 0xf7: /***** sm *****/
    MA = INDEXREGISTER;
    READ();
    DF = 0;
    RCA1802_SUBM();
    break;
case 0xf8: /***** ldi %1 *****/
    FETCH();
    D = MB;
    break;
case 0xf9: /***** ori %1 *****/
    FETCH();
    D |= MB;
    break;
case 0xfa: /***** ani %1 *****/
    FETCH();
    D &= MB;
    break;
case 0xfb: /***** xri %1 *****/
    FETCH();
    D ^= MB;
    break;
case 0xfc: /***** adi %1 *****/
    FETCH();
    DF = 0;
    RCA1802_ADD();
    break;
case 0xfd: /***** sdi %1 *****/
    FETCH();
    DF = 0;
    RCA1802_SUBD();
    break;
case 0xfe: /***** shl *****/
    DF = D >> 7;
    D = D << 1;
    break;
case 0xff: /***** smi %1 *****/
    FETCH();
    DF = 0;
    RCA1802_SUBM();
    break;

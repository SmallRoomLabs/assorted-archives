static BYTE8  D,DF,IE,Q,T,P,X;
static WORD16  R0,R1,R2,R3,R4,R5,R6,R7,R8,R9,RA,RB,RC,RD,RE,RF;
static BYTE8   MB,temp8;
static WORD16  MA,temp16,cycles;
static WORD16 *rPtr[16] = { &R0,&R1,&R2,&R3,&R4,&R5,&R6,&R7,&R8,&R9,&RA,&RB,&RC,&RD,&RE,&RF };
#define SETP(n) P = (n)
#define SETX(n) X = (n)
#define X_REGISTER (*rPtr[X])
#define P_REGISTER (*rPtr[P])
static void __RCA1802_Reset(void) {
 Q = 0;UPDATEQ(Q);IE = 1;
 SETX(0);SETP(0);R0 = 0;
}
#define RCA1802_ADD()  { temp16 = D + MB + DF; D = temp16; DF = temp16 >> 8; }
#define RCA1802_SUBD() { temp16 = MB - D - DF;D = temp16; DF = (temp16 >> 8) & 1; }
#define RCA1802_SUBM() { temp16 = D - MB - DF;D = temp16; DF = (temp16 >> 8) & 1; }
#define BRANCH()  P_REGISTER = ((P_REGISTER) & 0xFF00) | MB
#define LONGBRANCH()  P_REGISTER = temp16
#define LONGFETCH()  { FETCH();temp16 = MB << 8;FETCH();temp16 |= MB; }
static void __RCA1802_Interrupt(void) {
 if (IE != 0) {
  T = (X << 4) | P;
  SETP(1);
  SETX(2);
  IE = 0;
 }
}
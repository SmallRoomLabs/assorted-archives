// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		sys_processor.cpp
//		Purpose:	Processor Emulation.
//		Created:	1st January 2016
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include <stdlib.h>
#ifdef WINDOWS
#include <stdio.h>
#endif

#include "sys_processor.h"
#include "sys_debug_system.h"
#include "hardware.h"

// *******************************************************************************************************************************
//														   Timing
// *******************************************************************************************************************************

#define CRYSTAL_CLOCK 		(1760900L)												// Clock cycles per second (1.7609Mhz)
#define CYCLE_RATE 			(CRYSTAL_CLOCK/8)										// Cycles per second (8 clocks per cycle)
#define FRAME_RATE			(60)													// Frames per second (60)

#define CYCLES_PER_FRAME 	(CYCLE_RATE / FRAME_RATE)								// Cycles per frame (3,668)
#define CYCLES_PER_SCANLINE	(CYCLES_PER_FRAME / 262)								// Cycles per scanline (14)

// *******************************************************************************************************************************
//											Extra variables + memory
// *******************************************************************************************************************************

static BYTE8 	driverLines;														// 32 or 64 lines display
static BYTE8 	ramMemory[MEMORYSIZE];												// RAM Memory (0000 upwards)
static BYTE8 	eFlag1Value;														// Toggles eery EF1 read.

// *******************************************************************************************************************************
//												   Port Interfaces
// *******************************************************************************************************************************

#define INPORT1() 	HWISetScreenOn(1) 												// INP 1 Screen On
#define INPORT3() 	(0) 															// INP 3 Read ASCII keyboard

#define OUTPORT1(n) HWISetScreenOn(0) 												// OUT 1 Screen Off
#define OUTPORT2(n) {} 																// OUT 2 Set keyboard decode latch
#define OUTPORT3(n) {} 																// OUT 3 Sets pitch, before this 1.535Khz
#define OUTPORT4(n) {} 																// OUT 4 ROM Address latch, fudged.

#define EFLAG1() 	((++eFlag1Value) & 1)											// EFLAG 1 1861 Sync.
#define EFLAG2()	(0)																// EFLAG 2 Tape in (not used)
#define EFLAG3()	(0) 															// EFLAG 3 key pressed when 1.
#define EFLAG4() 	(0) 															// EFLAG 4 ASCII keyboard pressed when 1

#define UPDATEQ(n) 	{} 																// Sound on/off (and tape)

#include "1802/__1802ports.h"														// Default connections.

// *******************************************************************************************************************************
//											 Memory and I/O read and write macros.
// *******************************************************************************************************************************

#define READ() 		_Read()															
#define WRITE() 	_Write()

#define FETCH() 	MA = (*rPtr[P])++;READ();

#define THREECYCLES	cycles--														// Extra cycle for NOP,LSKP,LBR

#include "1802/__1802support.h"

static inline void _Read(void) {
	if (MA < MEMORYSIZE) {															// Reading RAM
		MB = ramMemory[MA];
		return;
	}
	MB = DEFAULT_BUS_VALUE;															// Anything else.
}

static inline void _Write(void) {
	if (MA < MEMORYSIZE) ramMemory[MA] = MB;										// Writing RAM
}

// *******************************************************************************************************************************
//														Reset the CPU
// *******************************************************************************************************************************

void CPUReset(void) {
	HWIReset();
	__RCA1802_Reset();
	driverLines = 0;
	cycles = CYCLES_PER_FRAME;														// Reset Cycles per Frame.
}

// *******************************************************************************************************************************
//												Execute a single instruction
// *******************************************************************************************************************************

BYTE8 CPUExecuteInstruction(void) {
	BYTE8 opcode;				

	FETCH();opcode = MB;															// Read the opcode

	switch(opcode) {																// Execute it.
		#include "1802/__1802opcodes.h"
	}

	cycles -= 2; 																	// Decrement cycles.

	if (cycles < 29 && IE != 0) {													// If we are at INT time.
		if (HWIGetScreenOn() != 0) {												// and interrupts are enabled, and the display is on.
			__RCA1802_Interrupt();													// Fire an interrupt
			cycles = 29;															// Make it EXACTLY 29 cycles to display start
																					// When breaks on FRAME_RATE then will be at render
		} 																			// If interrupt fires IE will be off.
	}

	if ((cycles & 0x8000) == 0) return 0;											// Not completed a frame.
	BYTE8 *ptr = NULL;																// NULL if R[0] is a bad pointer.							
	if (R0 <= MEMORYSIZE-256) ptr = ramMemory+R0;									// If in memory range, get pointer
	HWISetPageAddress(R0,ptr);														// Set the display address.

	if (driverLines == 0) {															// Is it a 32 or 64 line driver ?
		BYTE8 n = 0;
		driverLines = 32;															// Default to 32 lines
		while (n++ <= 6) {															// we look in the next 6 bytes for BN1
			MA = (*rPtr[P])+n;READ();												// and if we find BN1 (0x3C) it must be a 64 line driver
			if (MB == 0x3C) driverLines = 64;										// this is a bit of a cheat, but should work with the Elf original
		}																			// and the manual drivers. Esoteric ones won't work. Display depends
		//R[14] = driverLines; testing !											// on this and R0 value at Interrupt + 29 cycles. (e.g. here)
	}																				// should cope with basic variants e.g. Elf article vs Datasheet ok.
	
	HWIEndFrame(driverLines);														// End of Frame code
	cycles = cycles + CYCLES_PER_FRAME;												// Adjust this frame rate.
	if (HWIGetScreenOn()) {															// If screen is on.
		cycles = cycles - CYCLES_PER_SCANLINE * 128;								// We lose this much doing video
	}
	return FRAME_RATE;																// Return frame rate.
}

#ifdef INCLUDE_DEBUGGING_SUPPORT

// *******************************************************************************************************************************
//		Execute chunk of code, to either of two break points or frame-out, return non-zero frame rate on frame, breakpoint 0
// *******************************************************************************************************************************

BYTE8 CPUExecute(WORD16 breakPoint1,WORD16 breakPoint2) { 
	WORD16 rp;
	do {
		BYTE8 r = CPUExecuteInstruction();											// Execute an instruction
		if (r != 0) return r; 														// Frame out.
		rp = *rPtr[P];
	} while (rp != breakPoint1 && rp != breakPoint2);								// Stop on breakpoint.
	return 0; 
}

// *******************************************************************************************************************************
//									Return address of breakpoint for step-over, or 0 if N/A
// *******************************************************************************************************************************

WORD16 CPUGetStepOverBreakpoint(void) {
	WORD16 rp = *rPtr[P];
	BYTE8 opcode = CPUReadMemory(rp);												// Current opcode.
	if (opcode >= 0xD0 && opcode <= 0xDF) return (rp+1) & 0xFFFF;					// If SEP Rx then step is one after.
	return 0;																		// Do a normal single step
}

// *******************************************************************************************************************************
//												Read/Write Memory
// *******************************************************************************************************************************

BYTE8 CPUReadMemory(WORD16 address) {
	BYTE8 _MB = MB;WORD16 _MA = MA;BYTE8 result;
	MA = address;READ();result = MB;
	MB = _MB;MA = _MA;
	return result;
}

void CPUWriteMemory(WORD16 address,BYTE8 data) {
	BYTE8 _MB = MB;WORD16 _MA = MA;
	MA = address;MB = data;WRITE();
	MB = _MB;MA = _MA;
}

// *******************************************************************************************************************************
//												Load a binary file into RAM
// *******************************************************************************************************************************

#include <stdio.h>

void CPULoadBinary(const char *fileName) {
	FILE *f = fopen(fileName,"rb");
	fread(ramMemory,1,MEMORYSIZE,f);
	fclose(f);
}

// *******************************************************************************************************************************
//											Retrieve a snapshot of the processor
// *******************************************************************************************************************************

static CPUSTATUS s;																	// Status area

CPUSTATUS *CPUGetStatus(void) {
	s.d = D;s.df = DF;s.p = P;s.x = X;s.t = T;s.q = Q;s.ie = IE;					// Registers
	for (int i = 0;i < 16;i++) s.r[i] = *(rPtr[i]);									// 16 bit Registers
	s.cycles = cycles;s.pc = s.r[s.p];												// Cycles and "PC"
	s.screenLines = driverLines; 													// 32 or 64 line mode.
	return &s;
}

#endif

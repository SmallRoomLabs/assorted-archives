#ifndef INPORT00
#define INPORT00() {}
#endif
#ifndef INPORT01
#define INPORT01() {}
#endif
#ifndef INPORT02
#define INPORT02() {}
#endif
#ifndef INPORT03
#define INPORT03() {}
#endif
#ifndef INPORT04
#define INPORT04() {}
#endif
#ifndef INPORT05
#define INPORT05() {}
#endif
#ifndef INPORT06
#define INPORT06() {}
#endif
#ifndef INPORT07
#define INPORT07() {}
#endif
#ifndef OUTPORT08
#define OUTPORT08() {}
#endif
#ifndef OUTPORT09
#define OUTPORT09() {}
#endif
#ifndef OUTPORT0A
#define OUTPORT0A() {}
#endif
#ifndef OUTPORT0B
#define OUTPORT0B() {}
#endif
#ifndef OUTPORT0C
#define OUTPORT0C() {}
#endif
#ifndef OUTPORT0D
#define OUTPORT0D() {}
#endif
#ifndef OUTPORT0E
#define OUTPORT0E() {}
#endif
#ifndef OUTPORT0F
#define OUTPORT0F() {}
#endif
#ifndef OUTPORT10
#define OUTPORT10() {}
#endif
#ifndef OUTPORT11
#define OUTPORT11() {}
#endif
#ifndef OUTPORT12
#define OUTPORT12() {}
#endif
#ifndef OUTPORT13
#define OUTPORT13() {}
#endif
#ifndef OUTPORT14
#define OUTPORT14() {}
#endif
#ifndef OUTPORT15
#define OUTPORT15() {}
#endif
#ifndef OUTPORT16
#define OUTPORT16() {}
#endif
#ifndef OUTPORT17
#define OUTPORT17() {}
#endif
#ifndef OUTPORT18
#define OUTPORT18() {}
#endif
#ifndef OUTPORT19
#define OUTPORT19() {}
#endif
#ifndef OUTPORT1A
#define OUTPORT1A() {}
#endif
#ifndef OUTPORT1B
#define OUTPORT1B() {}
#endif
#ifndef OUTPORT1C
#define OUTPORT1C() {}
#endif
#ifndef OUTPORT1D
#define OUTPORT1D() {}
#endif
#ifndef OUTPORT1E
#define OUTPORT1E() {}
#endif
#ifndef OUTPORT1F
#define OUTPORT1F() {}
#endif
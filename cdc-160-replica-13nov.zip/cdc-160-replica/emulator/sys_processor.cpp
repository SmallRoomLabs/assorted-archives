// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		sys_processor.cpp
//		Purpose:	CDC160 Processor Emulation.
//		Created:	12th October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include "sys_processor.h"
#include "interface.h"
#include "driver_common.h"
#ifdef WINDOWS
#include <stdio.h>
#include "gfx.h"
#endif

// *******************************************************************************************************************************
//															Timing
// *******************************************************************************************************************************
	
#define CYCLES_PER_SECOND	(10000000/64)											// 6.4us Clock Speed
#define FRAME_RATE			(60)													// Frame rate
#define CYCLES_PER_FRAME	(CYCLES_PER_SECOND/FRAME_RATE)							// T-States per second.

#define RAMSIZE 			(4096) 													// Number of 12 bit words

// *******************************************************************************************************************************
//														Main Memory, CPU
// *******************************************************************************************************************************

static WORD16 A;
static WORD16 P;
static WORD16 Z;
static WORD16 S;
static BYTE8  F;
static BYTE8  HALT;
static WORD16 Cycles;

static BYTE8 coreMemory[6144];														// Program/Data Memory, compressed.
	
// *******************************************************************************************************************************
//													Memory read and write macros.
// *******************************************************************************************************************************

#define READ() 		Z = coreMemory[S]
#define WRITE() 	coreMemory[S] = Z

// *******************************************************************************************************************************
//														Reset the CPU
// *******************************************************************************************************************************

void CPUReset(void) {
	P = Z = A = S = F = HALT = 0;													// Clear all registers
	Cycles = 0;																		// Clear Cycle count.
	DRVRead(DRA1_RESET,0);DRVWrite(DWA1_RESET,0);									// Reset I/O Drivers
	DRVWrite(DWA1_WRITE,'C');DRVWrite(DWA1_WRITE,'D');DRVWrite(DWA1_WRITE,'C');		// Write CDC160 Prompt.
	DRVWrite(DWA1_WRITE,'1');DRVWrite(DWA1_WRITE,'6');DRVWrite(DWA1_WRITE,'0');
	DRVWrite(DWA1_NEWLINE,0);
	DIFInitialise();																// Re-initialise hardware.
}

// *******************************************************************************************************************************
//													 Execute a single instruction.
// *******************************************************************************************************************************

#include "__cdc160_support.h"

BYTE8 CPUExecuteInstruction(void) {
	if (HALT != 0) {																// CPU Halted
		Cycles = CYCLES_PER_FRAME;
		DRVRead(DRA1_FRAME,0);DRVWrite(DWA1_FRAME,0);DIFEndFrame();
		return FRAME_RATE;												
	}

	S = P;READ(); 																	// Read instruction
	F = Z & 00077;																	// Save lower 6 bits in F register
	switch(Z >> 6) {																// Switch on upper 6 bits.
		#include "__cdc160_opcodes.h"
	}

	if (HALT == 0 && Cycles < CYCLES_PER_FRAME) return 0;							// Frame in progress, return 0.
	Cycles = Cycles - CYCLES_PER_FRAME;
	if (HALT != 0) Cycles = 0;														// Fix up for HALT.
	DRVRead(DRA1_FRAME,0);DRVWrite(DWA1_FRAME,0);DIFEndFrame();
	return FRAME_RATE;																// Return the frame rate for sync speed.
}

// *******************************************************************************************************************************
//											Elapsed time in milliseconds
// *******************************************************************************************************************************

#ifdef WINDOWS
LONG32 SYSMilliseconds(void) {
	return GFXTimer();
}
#endif

// *******************************************************************************************************************************
//												Core Memory Read/Write
// *******************************************************************************************************************************
	
WORD16 CPURead(WORD16 address) {
	WORD16 _S,_Z,result;
	_S = S;_Z = Z;
	S = address;READ();result = Z;
	Z = _Z;S = _S;
	return result;
}

void CPUWrite(WORD16 address,WORD16 data) {
	WORD16 _S,_Z;
	_S = S;_Z = Z;
	S = address;Z = data;WRITE();
	Z = _Z;S = _S;
}


#ifdef INCLUDE_DEBUGGING_SUPPORT

// *******************************************************************************************************************************
//										 Get the step over breakpoint value
// *******************************************************************************************************************************

WORD16 CPUGetStepOverBreakpoint(void) {
	return 0xFFFF;
}

// *******************************************************************************************************************************
//										Run continuously till breakpoints / Halt.
// *******************************************************************************************************************************

BYTE8 CPUExecute(WORD16 break1,WORD16 break2) {
	BYTE8 rate = 0;
	while(1) {
		rate = CPUExecuteInstruction();												// Execute one instruction phase.
		if (rate != 0) {															// If end of frame, return rate.
			return rate;													
		}
		if (P == break1 || P == break2) return 0;
	} 																				// Until hit a breakpoint or HLT.
}

#include <stdio.h>

// *******************************************************************************************************************************
//											Retrieve a snapshot of the processor
// *******************************************************************************************************************************

static CPUSTATUS s;																	// Status area

CPUSTATUS *CPUGetStatus(void) {
	s.a = A;s.s = S;s.z = Z;s.p = P;s.cycles = Cycles;s.halt = HALT;
	return &s;
}
#endif

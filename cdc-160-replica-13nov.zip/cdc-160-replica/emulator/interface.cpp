// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		sys_debug_system.h
//		Purpose:	Debugger Code (System Dependent) Header
//		Created:	12th October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#include "sys_processor.h"
#include "interface.h"

#include <stdio.h>

void DIFInitialise(void) {
	printf("DIF:Initialise\n");
}

void DIFExternal(WORD16 exf) {
	printf("DIF:External %04o\n",exf);
}

WORD16 DIFWrite(WORD16 data) {
	printf("DIF:Write %04o\n",data);
	return 0xFFFF;
}

WORD16 DIFRead(void) {
	WORD16 rv = 0xFFFF;
	printf("DIF:Read %04o\n",rv);
	return rv;
}

BYTE8 DIFCanRead(void) {
	BYTE8 rv = 0;
	printf("DIF:CanRead %d\n",rv);
	return rv;
}

void DIFEndFrame(void) {
}
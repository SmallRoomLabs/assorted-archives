#define ROTATELEFT1(n)  ((((n) << 1) | ((n) >> 11)) & 07777)
#define ROTATELEFT3(n)  ((((n) << 3) | ((n) >> 0)) & 07777)
static WORD16 CDC160Add(WORD16 n1,WORD16 n2) {
 if (n1 == 07777 && n2 == 07777) return 07777;
 n1 = n1 + n2;
 if (n1 > 07777) {
  n1 = (n1 & 07777) + 1;
 }
 if (n1 == 07777) n1 = 0;
 return n1;
}
#define MINUS(x) ((x) ^ 07777)
static void CDC160BlockTransfer(BYTE8 command) {
 WORD16 r;
 S = CDC160Add(P,F);
 READ();A = Z;
 P = (P + 1) & 07777;
 do {
  if (command == DC_READ) {
   r = DIFRead();
   if (r != 0xFFFF) {
    Z = r;S = A;WRITE();
   }
  } else {
   S = A;READ();
   r = DIFWrite(Z);
  }
  if (r != 0xFFFF) {
   A = CDC160Add(A,1);
  }
  S = P;READ();
 } while (r != 0xFFFF && Z != A);
}
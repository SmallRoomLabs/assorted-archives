// *******************************************************************************************************************************
// *******************************************************************************************************************************
//
//		Name:		interface.h
//		Purpose:	Device Interface Header
//		Created:	12th October 2015
//		Author:		Paul Robson (paul@robsons.org.uk)
//
// *******************************************************************************************************************************
// *******************************************************************************************************************************

#ifndef _INTERFACE_H
#define _INTERFACE_H

#define DC_MEMORY				(0)
#define DC_INITIALISE			(1)
#define DC_SELECT				(2)
#define DC_DESELECT				(3)
#define DC_FUNCTION				(4)
#define DC_READ					(5)
#define DC_WRITE				(6)
#define DC_CANREAD				(7)

void DIFInitialise(void);
void DIFExternal(WORD16 exf);
WORD16 DIFWrite(WORD16 data);
WORD16 DIFRead(void);
BYTE8 DIFCanRead(void);
void  DIFEndFrame(void);

#endif
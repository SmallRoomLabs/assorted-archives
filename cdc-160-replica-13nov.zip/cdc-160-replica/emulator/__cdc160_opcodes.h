case 000: // **** 00 err ****
    HALT = 1;
    Cycles += 1;
    break;
case 001: // **** 01 sha ****
    if (F == 0102) A = ROTATELEFT1(A);
    if (F == 0110) A = ROTATELEFT3(A);
    if (F == 0112) A = CDC160Add(ROTATELEFT3(A),ROTATELEFT1(A));
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 002: // **** 02 lpn ****
    A &= F;
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 003: // **** 03 lsn ****
    A ^= F;
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 004: // **** 04 ldn ****
    A = F;
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 005: // **** 05 lcn ****
    A = MINUS(F);
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 006: // **** 06 adn ****
    A = CDC160Add(A,F);
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 007: // **** 07 sbn ****
    A = CDC160Add(A,MINUS(F));
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 010: // **** 10 lpd ****
    S = F;
    READ();
    A &= Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 011: // **** 11 lpi ****
    S = F;
    READ();
    S = Z;
    READ();
    A &= Z;
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 012: // **** 12 lpf ****
    S = CDC160Add(P,F);
    READ();
    A &= Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 013: // **** 13 lpb ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A &= Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 014: // **** 14 lsd ****
    S = F;
    READ();
    A ^= Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 015: // **** 15 lsi ****
    S = F;
    READ();
    S = Z;
    READ();
    A ^= Z;
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 016: // **** 16 lsf ****
    S = CDC160Add(P,F);
    READ();
    A ^= Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 017: // **** 17 lsb ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A ^= Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 020: // **** 20 ldd ****
    S = F;
    READ();
    A = Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 021: // **** 21 ldi ****
    S = F;
    READ();
    S = Z;
    READ();
    A = Z;
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 022: // **** 22 ldf ****
    S = CDC160Add(P,F);
    READ();
    A = Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 023: // **** 23 ldb ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A = Z;
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 024: // **** 24 lcd ****
    S = F;
    READ();
    A = MINUS(Z);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 025: // **** 25 lci ****
    S = F;
    READ();
    S = Z;
    READ();
    A = MINUS(Z);
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 026: // **** 26 lcf ****
    S = CDC160Add(P,F);
    READ();
    A = MINUS(Z);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 027: // **** 27 lcb ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A = MINUS(Z);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 030: // **** 30 add ****
    S = F;
    READ();
    A = CDC160Add(A,Z);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 031: // **** 31 adi ****
    S = F;
    READ();
    S = Z;
    READ();
    A = CDC160Add(A,Z);
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 032: // **** 32 adf ****
    S = CDC160Add(P,F);
    READ();
    A = CDC160Add(A,Z);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 033: // **** 33 adb ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A = CDC160Add(A,Z);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 034: // **** 34 sbd ****
    S = F;
    READ();
    A = CDC160Add(A,MINUS(Z));
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 035: // **** 35 sbi ****
    S = F;
    READ();
    S = Z;
    READ();
    A = CDC160Add(A,MINUS(Z));
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 036: // **** 36 sbf ****
    S = CDC160Add(P,F);
    READ();
    A = CDC160Add(A,MINUS(Z));
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 037: // **** 37 sbb ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A = CDC160Add(A,MINUS(Z));
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 040: // **** 40 std ****
    S = F;
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 041: // **** 41 sti ****
    S = F;
    READ();
    S = Z;
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 4;
    break;
case 042: // **** 42 stf ****
    S = CDC160Add(P,F);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 043: // **** 43 stb ****
    S = CDC160Add(P,MINUS(F));
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 044: // **** 44 srd ****
    S = F;
    READ();
    A = ROTATELEFT1(Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 045: // **** 45 sri ****
    S = F;
    READ();
    S = Z;
    READ();
    A = ROTATELEFT1(Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 4;
    break;
case 046: // **** 46 srf ****
    S = CDC160Add(P,F);
    READ();
    A = ROTATELEFT1(Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 047: // **** 47 srb ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A = ROTATELEFT1(Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 050: // **** 50 rad ****
    S = F;
    READ();
    A = CDC160Add(A,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 051: // **** 51 rai ****
    S = F;
    READ();
    S = Z;
    READ();
    A = CDC160Add(A,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 4;
    break;
case 052: // **** 52 raf ****
    S = CDC160Add(P,F);
    READ();
    A = CDC160Add(A,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 053: // **** 53 rab ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A = CDC160Add(A,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 054: // **** 54 aod ****
    S = F;
    READ();
    A = CDC160Add(1,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 055: // **** 55 aoi ****
    S = F;
    READ();
    S = Z;
    READ();
    A = CDC160Add(1,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 4;
    break;
case 056: // **** 56 aof ****
    S = CDC160Add(P,F);
    READ();
    A = CDC160Add(1,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 057: // **** 57 aob ****
    S = CDC160Add(P,MINUS(F));
    READ();
    A = CDC160Add(1,Z);
    Z = A;
    WRITE();
    P = (P + 1) & 07777;
    Cycles += 3;
    break;
case 060: // **** 60 zjf ****
    if (A == 0)
    {
    S = CDC160Add(P,F);
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 061: // **** 61 nzf ****
    if (A != 0)
    {
    S = CDC160Add(P,F);
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 062: // **** 62 pjf ****
    if ((A & 04000) == 0)
    {
    S = CDC160Add(P,F);
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 063: // **** 63 njf ****
    if ((A & 04000) != 0)
    {
    S = CDC160Add(P,F);
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 064: // **** 64 zjb ****
    if (A == 0)
    {
    S = CDC160Add(P,MINUS(F));
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 065: // **** 65 nzb ****
    if (A != 0)
    {
    S = CDC160Add(P,MINUS(F));
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 066: // **** 66 pjb ****
    if ((A & 04000) == 0)
    {
    S = CDC160Add(P,MINUS(F));
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 067: // **** 67 njb ****
    if ((A & 04000) != 0)
    {
    S = CDC160Add(P,MINUS(F));
    P = S;
    }
    else
    {
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 070: // **** 70 jpi ****
    S = F;
    READ();
    S = Z;
    P = S;
    Cycles += 2;
    break;
case 071: // **** 71 jfi ****
    S = CDC160Add(P,F);
    READ();
    P = Z;
    Cycles += 2;
    break;
case 072: // **** 72 inp ****
    if (DIFCanRead())
    {
    CDC160BlockTransfer(DC_READ);
    P = (P + 1) & 07777;
    }
    Cycles += 2;
    break;
case 073: // **** 73 out ****
    CDC160BlockTransfer(DC_WRITE);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 074: // **** 74 otn ****
    DIFWrite(F);
    P = (P + 1) & 07777;
    Cycles += 1;
    break;
case 075: // **** 75 exf ****
    S = CDC160Add(P,F);
    READ();
    DIFExternal(Z);
    P = (P + 1) & 07777;
    Cycles += 2;
    break;
case 076: // **** 76 ina ****
    if (DIFCanRead())
    {
    A = DIFRead();
    P = (P + 1) & 07777;
    }
    Cycles += 1;
    break;
case 077: // **** 77 hlt ****
    HALT = 1;
    Cycles += 1;
    break;

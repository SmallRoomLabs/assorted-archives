# *******************************************************************************************************************************
# *******************************************************************************************************************************
#
#		Name:		generate.py
#		Purpose:	Convert CDC160 Definitions into C-Code, Mnemonic List and Support file.
#		Created:	12th October 2015
#		Author:		Paul Robson (paul@robsons.org.uk)
#
# *******************************************************************************************************************************
# *******************************************************************************************************************************

import re

def process(s,opcode):
	s = s.replace("%M","DIFB"[opcode % 4])											# mode of access
	s = s.replace("%T",["ZJ","NZ","PJ","NJ"][opcode % 4])							# jump names.
																					# jump code.
	s = s.replace("%CCODE",["A == 0","A != 0","(A & 04000) == 0","(A & 04000) != 0"][opcode % 4])
	s = s.replace("%NEXT","P = (P + 1) & 07777")									# bump PC Code

	s = s.replace("%EACD","S = F")													# direct
	s = s.replace("%EACI","S = F;READ();S = Z")										# indirect
	s = s.replace("%EACF","S = CDC160Add(P,F)")										# forward
	s = s.replace("%EACB","S = CDC160Add(P,MINUS(F))")								# backward
	return s

source = open("cdc160.def").readlines()												# read source in
source = [x if x.find("//") < 0 else x[:x.find("//")] for x in source]				# remove comments.
source = [x.rstrip().replace("\t"," ") for x in source]								# right string, tabs to spaces.
source = [x for x in source if x != ""]												# remove blanks.

support = [x[1:] for x in source if x[0] == ':']									# strip out C code
open("__cdc160_support.h","w").write("\n".join(support))							# dump it.

source = [x for x in source if x[0] != ':']											# remove C code
source = "\n".join(source) 															# make a string
source = source.replace("\n ","")													# remove return-space to make lines
while source.find("  ") >= 0:														# remove multiple spaces
	source = source.replace("  "," ")
source = [x.strip() for x in source.split("\n")]									# split into seperate lines again.

mnemonics = [ None ] * 64 															# Mnemonics
code = [ None ] * 64 																# C Code for switch statement.

for l in source:																	# for each line.
	m = re.match("^([0-7\-]+)\s*([A-Z\%]+)\s*([0-9]+)\s*(.*)$",l)					# split into range,mnemonic,cycle,code
	assert m is not None
	r = m.group(1)+"-"+m.group(1) 													# make sure it is aa-bb
	for opcode in range(int(r[:2],8),int(r[3:5],8)+1):								# make into a range and iterate over it.
		assert mnemonics[opcode] is None
		mnemonics[opcode] = process(m.group(2),opcode).lower()						# save mnemonic
		cycles = int(m.group(3)) 													# number of cycles
		if opcode >= 0o10 and opcode < 0o60 and opcode % 4 == 1:					# memory reference indirect adds one cycle
			cycles += 1
																					# add cycles and break and store in code
		code[opcode] = process(m.group(4)+"Cycles += {0};break;".format(cycles),opcode);

open("__cdc160_mnemonics.h","w").write(",".join(['"'+x+'"' for x in mnemonics]))	# output mnemonics strings

handle = open("__cdc160_opcodes.h","w")												# create switch statement includes.
for opcode in range(0,64):															# work through opcodes and print out
	handle.write("case 0{0:02o}: // **** {0:02o} {1} ****\n".format(opcode,mnemonics[opcode]))
	c = code[opcode].replace(";",";@").replace("{","@{@").replace("}","@}@")		# a very simple reformatter, no indenting.
	c = [ "    "+x.strip() for x in c.split("@") if x.strip() != "" and x.strip() != ";" ]				
	handle.write("\n".join(c)+"\n")

# *******************************************************************************************************************************
# *******************************************************************************************************************************
#
#		Name:		osap.py
#		Purpose:	One Sixty Assembly Program in Python.
#		Created:	12th October 2015
#		Author:		Paul Robson (paul@robsons.org.uk)
#
# *******************************************************************************************************************************
# *******************************************************************************************************************************
#
#	Differences:
#
#	1) There is no real paper tape. Tape is output as a text file formatted |7654.321| where 1-7 represent holes 1-7.
#	   (Code is still output in bioctal format)
#	2) Input is via ASCII file(s), obviously. The formats in 4 a/b are replaced by the following which are compatible.
#			- a label is presented if the first character of a line is not tab or space
#			- spaces are *not* ignored in the assembly.
#			- an opcode is present if the first word past the label matches the opcode
#			- address and additive and comment (for the data instructions) fields are then included appropriately.
#			- any text following a backslash is a comment as this is not a flexowriter character thus cannot be an OSAP char
#			- /RETURN is not supported
#	
#	Enhancements:
#
#	1) Identifiers can be any length (well, within the limits of a PC)
#	2) = can be used instead of EQU.
#	3) there are no limits on the length of bcd/flx/tty/bcr/flr/ttr command text.
#	4) the bcd/etc. command text starts at the first non space character after the command itself.
#	
# *******************************************************************************************************************************

import re,sys

# *******************************************************************************************************************************
#
#									  Exception specifically for assembler errors.
#
# *******************************************************************************************************************************

class AssemblerException(Exception):
	def __init__(self, message):
		self.message = message
	def __str__(self):
		return self.message

# *******************************************************************************************************************************
#
#											Class wraps the standard vocabulary.
#
# *******************************************************************************************************************************

class StandardVocabulary:
	def __init__(self):																
		self.standard = {}																	# standard vocabulary words.
																							# text copied from mnemonics output.
		vocabulary = """														
			"err","sha","lpn","lsn","ldn","lcn","adn","sbn","lpd","lpi","lpf","lpb","lsd","lsi","lsf","lsb","ldd","ldi","ldf","ldb","lcd","lci","lcf","lcb","add","adi","adf","adb","sbd","sbi","sbf","sbb","std","sti","stf","stb","srd","sri","srf","srb","rad","rai","raf","rab","aod","aoi","aof","aob","zjf","nzf","pjf","njf","zjb","nzb","pjb","njb","jpi","jfi","inp","out","otn","exf","ina","hlt"
		""".strip().replace('"',"").split(",")												# remove spaces, quotes and split at commas

		for i in range(0,64):
			self.standard[vocabulary[i]] = i 												# store the standard vocabulary
			if vocabulary[i][-1] == "f" and i != 0o75:										# for F's (forward) except EXF (075)
				self.standard[vocabulary[i][:-1]+"r"] = -1 									# store as -1 as special case "relative"
	#
	#	Append the standard words to the given dictionary.
	#
	def append(self,dictionary):
		for mnemonic in self.standard.keys():												# add mnemonics to dictionary
			assert mnemonic not in dictionary
			dictionary[mnemonic] = self.standard[mnemonic]

# *******************************************************************************************************************************
#
#														Assembler Worker
#
# *******************************************************************************************************************************

class AssemblerWorker:
	def __init__(self):
		self.opcodes = {} 																	# known opcodes.
		StandardVocabulary().append(self.opcodes)											# add opcodes.
		self.dictionary = {} 																# dictionary of known identifiers
		for i in range(0,8):																# set up tem0..tem7
			self.assign("tem"+str(i),070+i)													# which are standard
		self.psuedoList = {} 																# pseudo operations
		pseudo = "org,con,prg,blr,wai,end,equ,rem,dec,bcd,flx,tty,bcr,flr,ttr,rem"
		for p in pseudo.split(","):															# create dictionary of psuedo ops
			self.psuedoList[p] = True	
		self.identifierMatch = "[A-Za-z][A-Za-z0-9]*"										# Identifier RegEx
	#
	#	Start a new pass.
	#
	def startPass(self,p):
		self.passNumber = p 																# set current pass number
		self.pointers = { "con" : 0o0002, "prg": 0o0100 }									# initialise location counter
		self.currentPointer = "prg"															# start with prg @ 0100 by default.
		self.endReached = False 															# not hit END pseudo-op.
		self.lineNumber = 0																	# reset line number
		print("Pass {0}".format(self.passNumber))
	#
	#	Assign a dictionary value.
	#
	def assign(self,identifier,value):
		identifier = identifier.lower()														# case insensitive
		if identifier in self.dictionary:													# if exists, check redefinition
			if self.dictionary[identifier] != value:										# if changed, that's an error.
				raise AssemblerException("Identifier {0} has been redefined".format(identifier))
		self.dictionary[identifier] = value 												# do the assignment.
	#
	#	Assemble a line
	#	
	def assembleLine(self,line):
		print("-----"+line)
		if line.find("\\") >= 0:															# remove \ comments. \ is not a 
			line = line[:line.find("\\")]													# valid flexowriter character
		line = line.rstrip().replace("\t"," ") 												# remove trailing characters, tab to space
		if line == "" or self.endReached:													# abandon if END or empty line.
			return
		if line[0] != ' ':																	# is there a label here ?
			m = re.match("^("+self.identifierMatch+")(.*)$",line)							# extract the label
			if m is None:																	# something wrong with the label.
				raise AssemblerException("Illegal label")
			self.assign(m.group(1),self.getPtr())											# assign the label.
			line = m.group(2)																# rest of the line.

		line = line.strip() 																# strip leading and trailing spaces
		if line == "":																		# return if empty.
			return

		m = re.match("^("+self.identifierMatch+")(.*)$",line)								# look for leading identifier.
		if m is not None:																	# found one.
			if m.group(1).lower() in self.opcodes:											# is it an opcode
				self.assembleOpcode(m.group(1).lower(),m.group(2).strip())					# assemble as opcode.
				return
			if m.group(1).lower() in self.psuedoList:										# is it a pseudo op ?
				print("Pseudo",m.groups(1))
				return

		w = self.evaluate(line,self.passNumber == 2)										# evaluate operand / additive
		#print(self.getPtr(),line,"{0:o}".format(w))
		self.assembleWord(w)																# assemble it.
	#
	#	Assemble as opcode.
	#
	def assembleOpcode(self,opcode,operand):											
		address = 0
		if self.opcodes[opcode] < 0:														# is it a relative (R) which asm does ?
			address = self.evaluate(operand,self.passNumber == 2) 							# evaluate the operand.
			if address < self.getPtr():														# backwards ?
				opcode = opcode[:2]+"b"														# do it backwards
			else:
				opcode = opcode[:2]+"f"														# do it forwards.

		if self.opcodes[opcode] >= 0 and operand != "":										# normal code with an operand
			address = self.evaluate(operand,self.passNumber == 2)

		if self.passNumber == 2:															# pass 2 operand checks.
			if opcode[-1] == 'f':															# forward ref
				address = (address - self.getPtr()) & 0o7777	
			if opcode[-1] == 'b':															# backward ref
				address = (self.getPtr() - address) & 0o7777	
			if address > 63:																# range error
				raise AssemblerException("Address range error")
		else:
			address = 0 																	# dummy value
		self.assembleWord((self.opcodes[opcode] << 6) | address)
	#
	#	Get current pointer for PRG or CON.
	#
	def getPtr(self):
		return self.pointers[self.currentPointer]
	#
	#	Assemble a word
	#
	def assembleWord(self,word):
		if self.currentPointer == "con" and self.pointers["con"] > 0o0077:					# con and con pointer out of range
			raise AssemblerException("con pointer has exceeded 0077")						# throw error.
		if self.passNumber == 2:															# only actually write on pass 2
			print("[{0:04o}] = {1:04o}".format(self.getPtr(),word))
		self.pointers[self.currentPointer] += 1												# bump pointer
		self.pointers[self.currentPointer] &= 0o7777 										# and wrap pointer
	#
	#	Evaluate text as operand plus additive.
	#
	def evaluate(self,line,requiredDefined):
		v = 0 																				# return value
		for sub in line.split(" "):															# subdivide into parts
			if sub != "":																	# remove nulls.
				sign = 1																	# check for sign
				if sub[0] == '+' or sub[0] == '-':											# leading sign ?
					sign = 1 if sub[0] == '+' else -1 										# put value in sign
					sub = sub[1:]															# drop sign
				if re.match("^[0-7]+$",sub):												# octal constant ?
					v = self.add(v,sign,int(sub,8))											# add it in.
				else:																		# identifier
					if requiredDefined:														# required to be defined.
						if sub.lower() not in self.dictionary:								# if not known
							raise AssemblerException("Identifier "+sub.lower()+" unknown")	# error
						v = self.add(v,sign,self.dictionary[sub.lower()])					# otherwise add it in.
		return v & 07777																	# return result in 12 bits.
	#
	#	Add 12 bit one's complement
	#
	def add(self,n1,sign,n2):
		if sign < 0:																		# if sign the negate n2
			n2 = n2 ^ 0o7777
		if n1 == 0o7777 and n2 == 0o7777:													# -0 + -0 special case.
			return 0o7777
		n1 = n1 + n2 																		# add
		if n1 > 0o7777:																		# end around carry
			n1 = (n1 & 0o7777) + 1		
		return 0 if n1 == 0o7777 else n1 													# -0 adjustment.

# *******************************************************************************************************************************
#
#	Main Program
#
# *******************************************************************************************************************************

src = """
		dec 	42
test 	41			\ comment
		lcf 	test101
		lcb 	test
		lcr 	test
test101	lcn 	42
		43
		5 	+4
		-2 	-1
		4 	-5
		test
		test101 3
		lcn 	5 +5
		lcd 	4
		lci 	4
"""

src = src.split("\n")
w = AssemblerWorker()
for p in range(1,3):
	w.startPass(p)
	for l in src:
		w.assembleLine(l)
	
print(w.dictionary)

# TODO: Pseudocodes
# 		Actual creation of binary/paper tape
#		Wrapper (can pinch)